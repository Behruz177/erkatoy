# Roadmap

- [x] Design system, auth, DB schema
- [x] Security findings fixed (RLS read policies scoped to staff roles)
- [x] Dashboard
- [x] Children list + CRUD
- [x] Child profile
- [x] Groups
- [x] Attendance
- [x] Payments
- [x] Debts
- [x] Waiting list
- [x] Reports (CSV + print/PDF)
- [x] Settings + notifications

## Yangi (2026-09-07)
- [x] Davomat sahifasida "+ To'lov" oynasi (to'lov kiritish, hissa va qarz avtomatik)
- [x] Guruh sahifasi /groups/$groupId: sarlavha statistikasi, sana tanlash, bolalar jadvali (№, bola, davomat, kelgan vaqti, shu oy to'lovi, oylik, qarz, holat, amallar), qidiruv + filtrlar
- [x] Bosh panelda guruh kartalari + "Guruhga kirish"
- [x] Oy tanlagich (to'lovlar oy bo'yicha)

## Yangi (2026-09-08)
- [x] Davomat sahifasidagi jadval endi to'liq: jadval sarlavhasida e'lon qilingan "Shu oy to'lovi", "Qarz", "To'lov holati" va "Amallar" ustunlari avval bo'sh edi — endi ShareBadge, qarz summasi, StatusBadge va "+ To'lov" tugmasi to'liq ishlaydi va PaymentModal ochiladi.
