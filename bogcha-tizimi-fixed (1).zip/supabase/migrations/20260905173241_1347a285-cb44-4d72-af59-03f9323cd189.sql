CREATE OR REPLACE FUNCTION public.setup_current_user(_full_name text)
RETURNS app_role
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  _uid uuid := auth.uid();
  _role public.app_role;
BEGIN
  IF _uid IS NULL THEN RAISE EXCEPTION 'not authenticated'; END IF;

  INSERT INTO public.profiles (user_id, full_name)
  VALUES (_uid, COALESCE(NULLIF(_full_name,''),'Xodim'))
  ON CONFLICT (user_id) DO UPDATE SET full_name = COALESCE(NULLIF(EXCLUDED.full_name,''), public.profiles.full_name);

  SELECT role INTO _role FROM public.user_roles WHERE user_id = _uid LIMIT 1;
  IF _role IS NOT NULL THEN RETURN _role; END IF;

  _role := 'teacher';
  INSERT INTO public.user_roles (user_id, role) VALUES (_uid, _role);
  RETURN _role;
END;
$function$;