import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { AppRole } from "@/lib/data";

export interface StaffSession {
  userId: string;
  email: string;
  fullName: string;
  role: AppRole;
}

export function useStaff() {
  return useQuery({
    queryKey: ["staff-session"],
    queryFn: async (): Promise<StaffSession | null> => {
      const { data: userData } = await supabase.auth.getUser();
      const user = userData.user;
      if (!user) return null;

      const [{ data: profile }, { data: roles }] = await Promise.all([
        supabase.from("profiles").select("full_name").eq("user_id", user.id).maybeSingle(),
        supabase.from("user_roles").select("role").eq("user_id", user.id),
      ]);

      return {
        userId: user.id,
        email: user.email ?? "",
        fullName: profile?.full_name || (user.email ?? "Xodim"),
        role: (roles?.[0]?.role as AppRole) ?? "teacher",
      };
    },
    staleTime: 60_000,
  });
}

export function canManageChildren(role?: AppRole) {
  return role === "admin";
}
export function canManageAttendance(role?: AppRole) {
  return role === "admin" || role === "teacher";
}
export function canManagePayments(role?: AppRole) {
  return role === "admin" || role === "accountant";
}

export const ROLE_LABELS: Record<AppRole, string> = {
  admin: "Administrator",
  teacher: "Tarbiyachi",
  accountant: "Hisobchi",
};
