import { useState, type ReactNode } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import {
  LayoutDashboard,
  Users,
  Boxes,
  CalendarCheck,
  Wallet,
  TriangleAlert,
  ListOrdered,
  FileBarChart,
  Settings,
  Menu,
  X,
  LogOut,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useStaff, ROLE_LABELS } from "@/hooks/useAuth";
import { initials } from "@/lib/format";

const NAV = [
  { to: "/dashboard", label: "Boshqaruv paneli", icon: LayoutDashboard },
  { to: "/children", label: "Bolalar", icon: Users },
  { to: "/groups", label: "Guruhlar", icon: Boxes },
  { to: "/attendance", label: "Davomat", icon: CalendarCheck },
  { to: "/payments", label: "To'lovlar", icon: Wallet },
  { to: "/debts", label: "Qarzdorlik", icon: TriangleAlert },
  { to: "/waiting-list", label: "Navbat", icon: ListOrdered },
  { to: "/reports", label: "Hisobotlar", icon: FileBarChart },
  { to: "/settings", label: "Sozlamalar", icon: Settings },
] as const;

function NavList({ onNavigate }: { onNavigate?: () => void }) {
  return (
    <nav className="mt-6 flex-1 space-y-1 overflow-y-auto pb-4">
      <span className="px-3 text-[10px] font-semibold uppercase tracking-[0.2em] text-muted-foreground/70">
        Menyu
      </span>
      {NAV.map(({ to, label, icon: Icon }) => (
        <Link
          key={to}
          to={to}
          onClick={onNavigate}
          className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
          activeProps={{
            className:
              "flex items-center gap-3 rounded-xl bg-primary/12 px-3 py-2.5 text-sm font-medium text-foreground ring-1 ring-primary/25",
          }}
        >
          <Icon className="size-4" strokeWidth={1.75} />
          {label}
        </Link>
      ))}
    </nav>
  );
}

function StaffCard() {
  const { data: staff } = useStaff();
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="mt-auto rounded-2xl bg-card/70 p-4 ring-1 ring-border/60">
      <div className="flex items-center gap-3">
        <div className="grid size-10 shrink-0 place-items-center rounded-full bg-primary/15 text-sm font-semibold text-primary ring-1 ring-primary/25">
          {initials(staff?.fullName ?? "X")}
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium text-foreground">
            {staff?.fullName ?? "…"}
          </p>
          <p className="text-[11px] text-muted-foreground">
            {staff ? ROLE_LABELS[staff.role] : ""}
          </p>
        </div>
        <button
          onClick={signOut}
          aria-label="Chiqish"
          className="rounded-lg p-2 text-muted-foreground ring-1 ring-border/60 transition-colors hover:text-foreground"
        >
          <LogOut className="size-4" />
        </button>
      </div>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-40 -left-32 size-[520px] rounded-full bg-accent/10 blur-[120px]" />
        <div className="absolute top-1/3 -right-40 size-[560px] rounded-full bg-primary/10 blur-[140px]" />
        <div className="absolute -bottom-52 left-1/3 size-[500px] rounded-full bg-accent/[0.08] blur-[150px]" />
      </div>

      <div className="relative flex min-h-screen">
        <aside className="hidden w-[268px] shrink-0 flex-col border-r border-border/60 bg-surface/70 px-5 py-6 lg:flex">
          <Brand />
          <NavList />
          <StaffCard />
        </aside>

        {open ? (
          <div className="fixed inset-0 z-40 lg:hidden">
            <div
              className="absolute inset-0 bg-background/80 backdrop-blur-sm"
              onClick={() => setOpen(false)}
            />
            <aside className="absolute left-0 top-0 flex h-full w-[280px] flex-col border-r border-border/60 bg-surface px-5 py-6">
              <div className="flex items-start justify-between">
                <Brand />
                <button
                  onClick={() => setOpen(false)}
                  aria-label="Yopish"
                  className="rounded-lg p-2 text-muted-foreground"
                >
                  <X className="size-4" />
                </button>
              </div>
              <NavList onNavigate={() => setOpen(false)} />
              <StaffCard />
            </aside>
          </div>
        ) : null}

        <main className="min-w-0 flex-1">
          <div className="sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-border/60 bg-surface/90 px-4 py-3 backdrop-blur lg:hidden">
            <Brand />
            <button
              onClick={() => setOpen(true)}
              aria-label="Menyu"
              className="inline-flex items-center gap-2 rounded-xl bg-primary px-3 py-2 text-sm font-medium text-primary-foreground shadow-glow"
            >
              <Menu className="size-4" />
              Menyu
            </button>
          </div>
          {children}
        </main>
      </div>
    </div>
  );
}

function Brand() {
  return (
    <div className="flex items-center gap-3 px-2">
      <div className="grid size-10 place-items-center rounded-xl bg-primary/15 ring-1 ring-primary/30">
        <span className="glowdot block size-3.5 rounded-full bg-primary shadow-glow" />
      </div>
      <div>
        <p className="font-display text-[15px] font-semibold leading-tight text-foreground">
          Bog'cha
        </p>
        <p className="text-[11px] tracking-wide text-muted-foreground">boshqaruv tizimi</p>
      </div>
    </div>
  );
}
