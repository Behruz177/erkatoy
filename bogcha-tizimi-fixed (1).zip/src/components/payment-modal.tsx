import { useEffect, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { notify, shareInfo, type Child, type Payment } from "@/lib/data";
import {
  currentPeriod,
  formatUZS,
  lastPeriods,
  periodLabel,
  todayISO,
} from "@/lib/format";
import { FormModal, SelectField, TextField } from "@/components/form-bits";

export const METHODS = [
  { value: "naqd", label: "Naqd" },
  { value: "karta", label: "Karta" },
  { value: "bank", label: "Bank" },
  { value: "boshqa", label: "Boshqa" },
];

/** To'lov oynasi — hissa va qarzni avtomatik hisoblaydi */
export function PaymentModal({
  child,
  period,
  payments,
  onOpenChange,
  createdBy,
}: {
  child: Child | null;
  period: string;
  payments: Payment[];
  onOpenChange: (v: boolean) => void;
  createdBy?: string | null;
}) {
  const qc = useQueryClient();
  const [month, setMonth] = useState(period || currentPeriod());
  const [amount, setAmount] = useState("");
  const [paidAt, setPaidAt] = useState(todayISO());
  const [method, setMethod] = useState("naqd");
  const [note, setNote] = useState("");

  useEffect(() => {
    if (child) {
      setMonth(period || currentPeriod());
      setAmount("");
      setPaidAt(todayISO());
      setMethod("naqd");
      setNote("");
    }
  }, [child, period]);

  const required = Number(child?.monthly_fee ?? 0);
  const paidBefore = payments
    .filter((p) => p.child_id === child?.id && p.period_month === month)
    .reduce((s, p) => s + Number(p.amount), 0);
  const entered = Number(amount) || 0;
  const paidAfter = paidBefore + entered;
  const debtAfter = Math.max(required - paidAfter, 0);
  const overpay = Math.max(paidAfter - required, 0);
  const share = shareInfo(required, paidAfter);

  const save = useMutation({
    mutationFn: async () => {
      if (!child) throw new Error("Bola tanlanmagan");
      if (entered <= 0) throw new Error("To'lov summasi 0 dan katta bo'lishi kerak");
      const { error } = await supabase.from("payments").insert({
        child_id: child.id,
        period_month: month,
        amount: entered,
        paid_at: paidAt,
        method,
        note: note || null,
        created_by: createdBy ?? null,
      });
      if (error) throw new Error(error.message);
      await notify(
        "payment",
        "To'lov qabul qilindi",
        `${child.full_name} — ${formatUZS(entered)} (${periodLabel(month)}). Qarz: ${formatUZS(
          Math.max(required - (paidBefore + entered), 0),
        )}`,
        child.id,
      );
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["payments"] });
      qc.invalidateQueries({ queryKey: ["notifications"] });
      toast.success("To'lov saqlandi, qarz yangilandi");
      onOpenChange(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <FormModal
      open={!!child}
      onOpenChange={onOpenChange}
      title="To'lov qo'shish"
      description={child ? `${child.full_name} — ${periodLabel(month)}` : undefined}
      submitLabel="To'lovni saqlash"
      submitting={save.isPending}
      onSubmit={() => save.mutate()}
    >
      <SelectField
        label="Oy"
        value={month}
        onChange={setMonth}
        options={lastPeriods(12)
          .slice()
          .reverse()
          .map((p) => ({ value: p, label: periodLabel(p) }))}
      />
      <TextField
        label="To'lov summasi (UZS)"
        type="number"
        value={amount}
        onChange={setAmount}
        placeholder="0"
        required
      />
      <div className="grid grid-cols-2 gap-3">
        <TextField label="To'lov sanasi" type="date" value={paidAt} onChange={setPaidAt} />
        <SelectField label="To'lov usuli" value={method} onChange={setMethod} options={METHODS} />
      </div>
      <TextField label="Izoh" value={note} onChange={setNote} placeholder="Ixtiyoriy" />

      <div className="rounded-xl bg-surface p-3 text-[12px] ring-1 ring-border/60">
        <div className="flex justify-between py-0.5">
          <span className="text-muted-foreground">Oylik to'lov</span>
          <span className="text-foreground">{formatUZS(required)}</span>
        </div>
        <div className="flex justify-between py-0.5">
          <span className="text-muted-foreground">Avval to'langan</span>
          <span className="text-foreground">{formatUZS(paidBefore)}</span>
        </div>
        <div className="flex justify-between py-0.5">
          <span className="text-muted-foreground">Ushbu to'lovdan keyin</span>
          <span className="text-foreground">{formatUZS(paidAfter)}</span>
        </div>
        <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-muted">
          <div
            className={
              debtAfter === 0
                ? "h-full rounded-full bg-primary"
                : "h-full rounded-full bg-warning"
            }
            style={{ width: `${share.percent}%` }}
          />
        </div>
        <div className="mt-2 flex justify-between">
          <span className="text-muted-foreground">To'lov hissasi</span>
          <span className="font-semibold text-foreground">{share.percent}%</span>
        </div>
        <div className="flex justify-between py-0.5">
          <span className="text-muted-foreground">Qoladigan qarz</span>
          <span className={debtAfter > 0 ? "font-semibold text-warning" : "text-foreground"}>
            {formatUZS(debtAfter)}
          </span>
        </div>
        {overpay > 0 ? (
          <div className="flex justify-between py-0.5">
            <span className="text-muted-foreground">Ortiqcha to'lov</span>
            <span className="text-primary">{formatUZS(overpay)}</span>
          </div>
        ) : null}
      </div>
    </FormModal>
  );
}

/** Kichik hissa ko'rsatkichi (jadval ichida) */
export function ShareBadge({ required, paid }: { required: number; paid: number }) {
  const share = shareInfo(required, paid);
  const debt = Math.max(required - paid, 0);
  const tone =
    debt === 0 && paid > 0
      ? "text-primary"
      : paid > 0
        ? "text-warning"
        : "text-destructive";
  return (
    <div className="min-w-28">
      <div className="flex items-center justify-between gap-2 text-[12px]">
        <span className={`font-semibold ${tone}`}>{share.percent}%</span>
        <span className="text-muted-foreground">{formatUZS(paid)}</span>
      </div>
      <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-muted">
        <div
          className={
            debt === 0 && paid > 0
              ? "h-full rounded-full bg-primary"
              : "h-full rounded-full bg-warning"
          }
          style={{ width: `${share.percent}%` }}
        />
      </div>
    </div>
  );
}

/** To'lov holati belgisi */
export function StatusBadge({ status }: { status: "paid" | "partial" | "unpaid" }) {
  const map = {
    paid: { label: "\u{1F7E2} To'langan", cls: "bg-primary/12 text-primary ring-primary/25" },
    partial: { label: "\u{1F7E1} Qisman", cls: "bg-warning/12 text-warning ring-warning/25" },
    unpaid: {
      label: "\u{1F534} To'lanmagan",
      cls: "bg-destructive/12 text-destructive ring-destructive/25",
    },
  } as const;
  const s = map[status];
  return (
    <span className={`rounded-lg px-2.5 py-1 text-[11px] font-medium ring-1 ${s.cls}`}>
      {s.label}
    </span>
  );
}
