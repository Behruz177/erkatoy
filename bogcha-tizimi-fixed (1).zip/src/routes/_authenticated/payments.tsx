import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import {
  childrenQuery,
  groupsQuery,
  notify,
  paymentsQuery,
  summarize,
  type Payment,
} from "@/lib/data";
import {
  currentPeriod,
  formatDate,
  formatUZS,
  lastPeriods,
  periodLabel,
  todayISO,
} from "@/lib/format";
import { canManagePayments, useStaff } from "@/hooks/useAuth";
import {
  EmptyState,
  ErrorNote,
  LoadingRows,
  PageTitle,
  Panel,
  PanelHeader,
  Pill,
  StatCard,
} from "@/components/ui-bits";
import {
  ConfirmDialog,
  FilterSelect,
  FormModal,
  GhostButton,
  PrimaryButton,
  SearchInput,
  SelectField,
  TextField,
} from "@/components/form-bits";

export const Route = createFileRoute("/_authenticated/payments")({
  head: () => ({
    meta: [
      { title: "To'lovlar — Bog'cha tizimi" },
      {
        name: "description",
        content: "Oylik to'lovlar, qisman to'lovlar va qarzdorlikni hisoblash.",
      },
      { property: "og:title", content: "To'lovlar — Bog'cha tizimi" },
      { property: "og:description", content: "To'lovlarni qayd etish va kuzatish." },
    ],
  }),
  component: PaymentsPage,
});

export const METHODS = [
  { value: "naqd", label: "Naqd" },
  { value: "karta", label: "Karta" },
  { value: "bank", label: "Bank o'tkazma" },
];

const schema = z.object({
  child_id: z.string().uuid("Bolani tanlang"),
  amount: z.number().positive("Summa 0 dan katta bo'lsin").max(100_000_000),
});

function PaymentsPage() {
  const qc = useQueryClient();
  const { data: staff } = useStaff();
  const canEdit = canManagePayments(staff?.role);

  const [period, setPeriod] = useState(currentPeriod());
  const [groupId, setGroupId] = useState("all");
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [deleting, setDeleting] = useState<Payment | null>(null);
  const [form, setForm] = useState({
    child_id: "",
    amount: "",
    paid_at: todayISO(),
    method: "naqd",
    note: "",
  });

  const childrenRes = useQuery(childrenQuery());
  const groupsRes = useQuery(groupsQuery());
  const paymentsRes = useQuery(paymentsQuery());

  const children = childrenRes.data ?? [];
  const groups = groupsRes.data ?? [];
  const periodPayments = (paymentsRes.data ?? []).filter((p) => p.period_month === period);

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return children
      .filter((c) => c.status === "active")
      .filter((c) => groupId === "all" || c.group_id === groupId)
      .filter((c) => !q || c.full_name.toLowerCase().includes(q))
      .map((c) => ({
        child: c,
        payments: periodPayments.filter((p) => p.child_id === c.id),
        summary: summarize(
          c,
          periodPayments.filter((p) => p.child_id === c.id),
        ),
      }));
  }, [children, periodPayments, groupId, search]);

  const totalPaid = rows.reduce((s, r) => s + r.summary.paid, 0);
  const totalRequired = rows.reduce((s, r) => s + r.summary.required, 0);
  const totalDebt = rows.reduce((s, r) => s + r.summary.debt, 0);

  const save = useMutation({
    mutationFn: async () => {
      const parsed = schema.safeParse({
        child_id: form.child_id,
        amount: Number(form.amount || 0),
      });
      if (!parsed.success) throw new Error(parsed.error.issues[0]!.message);
      const { error } = await supabase.from("payments").insert({
        child_id: parsed.data.child_id,
        amount: parsed.data.amount,
        period_month: period,
        paid_at: form.paid_at || todayISO(),
        method: form.method,
        note: form.note || null,
        created_by: staff?.userId ?? null,
      });
      if (error) throw new Error(error.message);
      const child = children.find((c) => c.id === parsed.data.child_id);
      await notify(
        "payment",
        "To'lov qabul qilindi",
        `${child?.full_name ?? "Bola"} · ${formatUZS(parsed.data.amount)} (${periodLabel(period)})`,
        parsed.data.child_id,
      );
    },
    onSuccess: () => {
      toast.success("To'lov qo'shildi");
      setOpen(false);
      setForm({ child_id: "", amount: "", paid_at: todayISO(), method: "naqd", note: "" });
      qc.invalidateQueries({ queryKey: ["payments"] });
      qc.invalidateQueries({ queryKey: ["notifications"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (p: Payment) => {
      const { error } = await supabase.from("payments").delete().eq("id", p.id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      toast.success("To'lov o'chirildi");
      setDeleting(null);
      qc.invalidateQueries({ queryKey: ["payments"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <>
      <PageTitle
        eyebrow={periodLabel(period)}
        title="To'lovlar"
        actions={
          canEdit ? (
            <PrimaryButton onClick={() => setOpen(true)}>To'lov qo'shish</PrimaryButton>
          ) : null
        }
      />

      <div className="space-y-6 px-5 py-6 lg:px-6">
        <section className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <StatCard label="Kerakli summa" value={formatUZS(totalRequired)} />
          <StatCard label="To'langan" value={formatUZS(totalPaid)} tone="primary" />
          <StatCard label="Qarz" value={formatUZS(totalDebt)} tone="warning" />
          <StatCard
            label="To'liq to'laganlar"
            value={`${rows.filter((r) => r.summary.status === "paid").length} / ${rows.length}`}
          />
        </section>

        <Panel>
          <PanelHeader
            title="Oylik to'lov holati"
            subtitle={periodLabel(period)}
            actions={
              <>
                <SearchInput value={search} onChange={setSearch} placeholder="Bola ismi…" />
                <FilterSelect
                  ariaLabel="Oy"
                  value={period}
                  onChange={setPeriod}
                  options={lastPeriods(12)
                    .slice()
                    .reverse()
                    .map((p) => ({ value: p, label: periodLabel(p) }))}
                />
                <FilterSelect
                  ariaLabel="Guruh"
                  value={groupId}
                  onChange={setGroupId}
                  options={[
                    { value: "all", label: "Guruh: Barchasi" },
                    ...groups.map((g) => ({ value: g.id, label: g.name })),
                  ]}
                />
              </>
            }
          />

          {paymentsRes.isLoading || childrenRes.isLoading ? (
            <LoadingRows />
          ) : paymentsRes.error ? (
            <ErrorNote message={(paymentsRes.error as Error).message} />
          ) : rows.length === 0 ? (
            <EmptyState title="Ma'lumot topilmadi" />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-border/60 text-[11px] uppercase tracking-wider text-muted-foreground">
                    <th className="px-5 py-3 font-medium">Bola</th>
                    <th className="px-5 py-3 font-medium">Kerak</th>
                    <th className="px-5 py-3 font-medium">To'langan</th>
                    <th className="px-5 py-3 font-medium">Qarz</th>
                    <th className="hidden px-5 py-3 font-medium md:table-cell">
                      So'nggi to'lov
                    </th>
                    <th className="px-5 py-3 font-medium">Holat</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {rows.map(({ child, summary }) => (
                    <tr key={child.id} className="hover:bg-primary/5">
                      <td className="px-5 py-3 font-medium text-foreground">
                        {child.full_name}
                      </td>
                      <td className="px-5 py-3 text-muted-foreground">
                        {formatUZS(summary.required)}
                      </td>
                      <td className="px-5 py-3 text-foreground">{formatUZS(summary.paid)}</td>
                      <td className="px-5 py-3 text-foreground">{formatUZS(summary.debt)}</td>
                      <td className="hidden px-5 py-3 text-muted-foreground md:table-cell">
                        {formatDate(summary.lastPaidAt)}
                      </td>
                      <td className="px-5 py-3">
                        {summary.status === "paid" ? (
                          <Pill tone="primary">To'langan</Pill>
                        ) : summary.status === "partial" ? (
                          <Pill tone="warning">Qisman</Pill>
                        ) : (
                          <Pill tone="muted">To'lanmagan</Pill>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Panel>

        <Panel>
          <PanelHeader title="To'lov tarixi" subtitle={`${periodPayments.length} ta yozuv`} />
          {periodPayments.length === 0 ? (
            <EmptyState title="Bu oyda to'lov yo'q" />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-border/60 text-[11px] uppercase tracking-wider text-muted-foreground">
                    <th className="px-5 py-3 font-medium">Sana</th>
                    <th className="px-5 py-3 font-medium">Bola</th>
                    <th className="px-5 py-3 font-medium">Summa</th>
                    <th className="hidden px-5 py-3 font-medium sm:table-cell">Usul</th>
                    <th className="hidden px-5 py-3 font-medium lg:table-cell">Izoh</th>
                    <th className="px-5 py-3 text-right font-medium">Amal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {periodPayments.map((p) => (
                    <tr key={p.id} className="hover:bg-primary/5">
                      <td className="px-5 py-3 text-muted-foreground">{formatDate(p.paid_at)}</td>
                      <td className="px-5 py-3 text-foreground">
                        {children.find((c) => c.id === p.child_id)?.full_name ?? "—"}
                      </td>
                      <td className="px-5 py-3 text-foreground">{formatUZS(p.amount)}</td>
                      <td className="hidden px-5 py-3 text-muted-foreground sm:table-cell">
                        {METHODS.find((m) => m.value === p.method)?.label ?? p.method}
                      </td>
                      <td className="hidden px-5 py-3 text-muted-foreground lg:table-cell">
                        {p.note || "—"}
                      </td>
                      <td className="px-5 py-3 text-right">
                        {canEdit ? (
                          <GhostButton onClick={() => setDeleting(p)}>O'chirish</GhostButton>
                        ) : null}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Panel>
      </div>

      <FormModal
        open={open}
        onOpenChange={setOpen}
        title="Yangi to'lov"
        description={`${periodLabel(period)} uchun to'lov qayd etiladi.`}
        submitting={save.isPending}
        onSubmit={() => save.mutate()}
      >
        <SelectField
          label="Bola"
          value={form.child_id}
          onChange={(v) => setForm({ ...form, child_id: v })}
          options={[
            { value: "", label: "Tanlang…" },
            ...children
              .filter((c) => c.status === "active")
              .map((c) => ({ value: c.id, label: c.full_name })),
          ]}
        />
        <div className="grid gap-3 sm:grid-cols-2">
          <TextField
            label="Summa (UZS)"
            type="number"
            required
            value={form.amount}
            onChange={(v) => setForm({ ...form, amount: v })}
          />
          <TextField
            label="To'lov sanasi"
            type="date"
            value={form.paid_at}
            onChange={(v) => setForm({ ...form, paid_at: v })}
          />
        </div>
        <SelectField
          label="To'lov usuli"
          value={form.method}
          onChange={(v) => setForm({ ...form, method: v })}
          options={METHODS}
        />
        <TextField
          label="Izoh"
          value={form.note}
          onChange={(v) => setForm({ ...form, note: v })}
        />
      </FormModal>

      <ConfirmDialog
        open={deleting !== null}
        onOpenChange={(v) => !v && setDeleting(null)}
        title="To'lovni o'chirish"
        description="Bu to'lov yozuvi o'chiriladi va qarzdorlik qayta hisoblanadi."
        onConfirm={() => deleting && remove.mutate(deleting)}
      />
    </>
  );
}
