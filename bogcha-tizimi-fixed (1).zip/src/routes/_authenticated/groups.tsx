import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { childrenQuery, groupsQuery, type Group } from "@/lib/data";
import { formatUZS } from "@/lib/format";
import { canManageChildren, useStaff } from "@/hooks/useAuth";
import {
  EmptyState,
  ErrorNote,
  LoadingRows,
  PageTitle,
  Panel,
  PanelHeader,
} from "@/components/ui-bits";
import {
  ConfirmDialog,
  FormModal,
  GhostButton,
  PrimaryButton,
  TextField,
} from "@/components/form-bits";

export const Route = createFileRoute("/_authenticated/groups")({
  head: () => ({
    meta: [
      { title: "Guruhlar — Bog'cha tizimi" },
      {
        name: "description",
        content: "Guruhlar, tarbiyachilar, sig'im va oylik to'lovlarni boshqarish.",
      },
      { property: "og:title", content: "Guruhlar — Bog'cha tizimi" },
      { property: "og:description", content: "Bog'cha guruhlarini boshqarish." },
    ],
  }),
  component: GroupsPage,
});

const schema = z.object({
  name: z.string().trim().min(1, "Guruh nomi kerak").max(60),
  teacher_name: z.string().trim().max(80),
  capacity: z.number().int().min(1).max(200),
  monthly_fee: z.number().min(0).max(100_000_000),
});

const empty = { name: "", teacher_name: "", capacity: "20", monthly_fee: "0" };

function GroupsPage() {
  const qc = useQueryClient();
  const { data: staff } = useStaff();
  const canEdit = canManageChildren(staff?.role);

  const groupsRes = useQuery(groupsQuery());
  const childrenRes = useQuery(childrenQuery());
  const children = childrenRes.data ?? [];

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Group | null>(null);
  const [form, setForm] = useState(empty);
  const [deleting, setDeleting] = useState<Group | null>(null);

  const save = useMutation({
    mutationFn: async () => {
      const parsed = schema.safeParse({
        name: form.name,
        teacher_name: form.teacher_name,
        capacity: Number(form.capacity || 0),
        monthly_fee: Number(form.monthly_fee || 0),
      });
      if (!parsed.success) throw new Error(parsed.error.issues[0]!.message);
      if (editing) {
        const { error } = await supabase
          .from("groups")
          .update(parsed.data)
          .eq("id", editing.id);
        if (error) throw new Error(error.message);
      } else {
        const { error } = await supabase.from("groups").insert(parsed.data);
        if (error) throw new Error(error.message);
      }
    },
    onSuccess: () => {
      toast.success(editing ? "Guruh yangilandi" : "Guruh qo'shildi");
      setOpen(false);
      setEditing(null);
      qc.invalidateQueries({ queryKey: ["groups"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (g: Group) => {
      const { error } = await supabase.from("groups").delete().eq("id", g.id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      toast.success("Guruh o'chirildi");
      setDeleting(null);
      qc.invalidateQueries({ queryKey: ["groups"] });
      qc.invalidateQueries({ queryKey: ["children"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <>
      <PageTitle
        eyebrow={`${(groupsRes.data ?? []).length} ta guruh`}
        title="Guruhlar"
        actions={
          canEdit ? (
            <PrimaryButton
              onClick={() => {
                setEditing(null);
                setForm(empty);
                setOpen(true);
              }}
            >
              Guruh qo'shish
            </PrimaryButton>
          ) : null
        }
      />

      <div className="px-5 py-6 lg:px-6">
        {groupsRes.isLoading ? (
          <Panel>
            <LoadingRows />
          </Panel>
        ) : groupsRes.error ? (
          <Panel>
            <ErrorNote message={(groupsRes.error as Error).message} />
          </Panel>
        ) : (groupsRes.data ?? []).length === 0 ? (
          <Panel>
            <EmptyState title="Guruhlar yo'q" hint="Birinchi guruhni qo'shing." />
          </Panel>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {(groupsRes.data ?? []).map((g) => {
              const count = children.filter(
                (c) => c.group_id === g.id && c.status === "active",
              ).length;
              const pct = Math.min(Math.round((count / Math.max(g.capacity, 1)) * 100), 100);
              return (
                <Panel key={g.id} className="p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h3 className="font-display text-lg text-foreground">{g.name}</h3>
                      <p className="text-[12px] text-muted-foreground">
                        Tarbiyachi: {g.teacher_name || "—"}
                      </p>
                    </div>
                    <span className="rounded-lg bg-primary/12 px-2.5 py-1 text-[11px] font-medium text-primary ring-1 ring-primary/25">
                      {formatUZS(g.monthly_fee)}
                    </span>
                  </div>

                  <div className="mt-4 space-y-1.5">
                    <div className="flex justify-between text-[12px] text-muted-foreground">
                      <span>To'ldirilganlik</span>
                      <span className="text-foreground">
                        {count} / {g.capacity}
                      </span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-surface ring-1 ring-border/60">
                      <div
                        className="h-full rounded-full bg-primary"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>

                  <Link
                    to="/group/$groupId"
                    params={{ groupId: g.id }}
                    className="mt-4 flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-glow"
                  >
                    Guruhga kirish →
                  </Link>

                  {canEdit ? (
                    <div className="mt-4 flex flex-wrap gap-2">
                      <Link
                        to="/children"
                        search={{ add: g.id }}
                        className="rounded-lg bg-primary/12 px-3 py-1.5 text-[12px] font-medium text-primary ring-1 ring-primary/25 hover:bg-primary/20"
                      >
                        + Bola qo'shish
                      </Link>
                      <GhostButton
                        onClick={() => {
                          setEditing(g);
                          setForm({
                            name: g.name,
                            teacher_name: g.teacher_name ?? "",
                            capacity: String(g.capacity),
                            monthly_fee: String(g.monthly_fee),
                          });
                          setOpen(true);
                        }}
                      >
                        Tahrirlash
                      </GhostButton>
                      <GhostButton onClick={() => setDeleting(g)}>O'chirish</GhostButton>
                    </div>
                  ) : null}
                </Panel>
              );
            })}
          </div>
        )}
      </div>

      <FormModal
        open={open}
        onOpenChange={setOpen}
        title={editing ? "Guruhni tahrirlash" : "Yangi guruh"}
        submitting={save.isPending}
        onSubmit={() => save.mutate()}
      >
        <TextField
          label="Guruh nomi"
          required
          value={form.name}
          onChange={(v) => setForm({ ...form, name: v })}
        />
        <TextField
          label="Tarbiyachi"
          value={form.teacher_name}
          onChange={(v) => setForm({ ...form, teacher_name: v })}
        />
        <div className="grid gap-3 sm:grid-cols-2">
          <TextField
            label="Maksimal sig'im"
            type="number"
            value={form.capacity}
            onChange={(v) => setForm({ ...form, capacity: v })}
          />
          <TextField
            label="Oylik to'lov (UZS)"
            type="number"
            value={form.monthly_fee}
            onChange={(v) => setForm({ ...form, monthly_fee: v })}
          />
        </div>
      </FormModal>

      <ConfirmDialog
        open={deleting !== null}
        onOpenChange={(v) => !v && setDeleting(null)}
        title="Guruhni o'chirish"
        description={`${deleting?.name ?? ""} guruhi o'chiriladi. Bolalar guruhsiz qoladi.`}
        onConfirm={() => deleting && remove.mutate(deleting)}
      />
    </>
  );
}
