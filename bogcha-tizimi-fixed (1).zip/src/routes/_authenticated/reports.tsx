import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  attendanceRangeQuery,
  childrenQuery,
  groupsQuery,
  paymentsQuery,
  summarize,
  waitingListQuery,
} from "@/lib/data";
import {
  currentPeriod,
  downloadCSV,
  formatDate,
  formatUZS,
  lastPeriods,
  periodLabel,
} from "@/lib/format";
import {
  EmptyState,
  PageTitle,
  Panel,
  PanelHeader,
  StatCard,
} from "@/components/ui-bits";
import { FilterSelect, GhostButton, PrimaryButton } from "@/components/form-bits";

export const Route = createFileRoute("/_authenticated/reports")({
  head: () => ({
    meta: [
      { title: "Hisobotlar — Bog'cha tizimi" },
      {
        name: "description",
        content: "To'lov, qarz, davomat, bolalar va navbat hisobotlari; CSV va PDF eksport.",
      },
      { property: "og:title", content: "Hisobotlar — Bog'cha tizimi" },
      { property: "og:description", content: "Oylik hisobotlarni yuklab olish." },
    ],
  }),
  component: ReportsPage,
});

type ReportKind = "payments" | "debts" | "attendance" | "children" | "waiting";

const KINDS: { value: ReportKind; label: string }[] = [
  { value: "payments", label: "To'lovlar hisoboti" },
  { value: "debts", label: "Qarzdorlik hisoboti" },
  { value: "attendance", label: "Davomat hisoboti" },
  { value: "children", label: "Bolalar hisoboti" },
  { value: "waiting", label: "Navbat hisoboti" },
];

function monthRange(period: string) {
  const [y, m] = period.split("-").map(Number);
  const from = `${period.slice(0, 7)}-01`;
  const last = new Date(y!, m!, 0).getDate();
  return { from, to: `${period.slice(0, 7)}-${String(last).padStart(2, "0")}` };
}

function ReportsPage() {
  const [kind, setKind] = useState<ReportKind>("payments");
  const [period, setPeriod] = useState(currentPeriod());
  const [groupId, setGroupId] = useState("all");

  const { from, to } = monthRange(period);
  const childrenRes = useQuery(childrenQuery());
  const groupsRes = useQuery(groupsQuery());
  const paymentsRes = useQuery(paymentsQuery());
  const waitingRes = useQuery(waitingListQuery());
  const attRes = useQuery(attendanceRangeQuery(from, to));

  const groups = groupsRes.data ?? [];
  const children = (childrenRes.data ?? []).filter(
    (c) => groupId === "all" || c.group_id === groupId,
  );
  const periodPayments = (paymentsRes.data ?? []).filter(
    (p) => p.period_month === period && children.some((c) => c.id === p.child_id),
  );
  const attendance = (attRes.data ?? []).filter((a) =>
    children.some((c) => c.id === a.child_id),
  );

  const table = useMemo(() => {
    const gname = (id: string | null) => groups.find((g) => g.id === id)?.name ?? "Guruhsiz";

    if (kind === "payments") {
      return {
        head: ["Sana", "Bola", "Guruh", "Summa", "Usul"],
        rows: periodPayments.map((p) => {
          const c = children.find((x) => x.id === p.child_id);
          return [
            formatDate(p.paid_at),
            c?.full_name ?? "—",
            gname(c?.group_id ?? null),
            formatUZS(p.amount),
            p.method,
          ];
        }),
      };
    }
    if (kind === "debts") {
      return {
        head: ["Bola", "Guruh", "Telefon", "Kerak", "To'langan", "Qarz"],
        rows: children
          .filter((c) => c.status === "active")
          .map((c) => ({
            c,
            s: summarize(
              c,
              periodPayments.filter((p) => p.child_id === c.id),
            ),
          }))
          .filter((r) => r.s.debt > 0)
          .map((r) => [
            r.c.full_name,
            gname(r.c.group_id),
            r.c.parent_phone || "—",
            formatUZS(r.s.required),
            formatUZS(r.s.paid),
            formatUZS(r.s.debt),
          ]),
      };
    }
    if (kind === "attendance") {
      return {
        head: ["Bola", "Guruh", "Keldi", "Kechikdi", "Kelmadi"],
        rows: children
          .filter((c) => c.status === "active")
          .map((c) => {
            const rows = attendance.filter((a) => a.child_id === c.id);
            return [
              c.full_name,
              gname(c.group_id),
              String(rows.filter((a) => a.status === "present").length),
              String(rows.filter((a) => a.status === "late").length),
              String(rows.filter((a) => a.status === "absent").length),
            ];
          }),
      };
    }
    if (kind === "children") {
      return {
        head: ["Kod", "Bola", "Tug'ilgan", "Ota-ona", "Telefon", "Guruh", "Oylik", "Holat"],
        rows: children.map((c) => [
          c.child_code,
          c.full_name,
          formatDate(c.birth_date),
          c.parent_name || "—",
          c.parent_phone || "—",
          gname(c.group_id),
          formatUZS(c.monthly_fee),
          c.status,
        ]),
      };
    }
    return {
      head: ["#", "Bola", "Ota-ona", "Telefon", "Ariza sanasi", "Holat"],
      rows: (waitingRes.data ?? []).map((w) => [
        String(w.position),
        w.full_name,
        w.parent_name || "—",
        w.parent_phone || "—",
        formatDate(w.applied_date),
        w.status,
      ]),
    };
  }, [kind, children, groups, periodPayments, attendance, waitingRes.data]);

  const totalPaid = periodPayments.reduce((s, p) => s + Number(p.amount), 0);
  const totalDebt = children
    .filter((c) => c.status === "active")
    .reduce(
      (s, c) =>
        s +
        summarize(
          c,
          periodPayments.filter((p) => p.child_id === c.id),
        ).debt,
      0,
    );

  return (
    <>
      <PageTitle
        eyebrow={periodLabel(period)}
        title="Hisobotlar"
        actions={
          <>
            <GhostButton
              onClick={() => {
                downloadCSV(`${kind}-${period}.csv`, [table.head, ...table.rows]);
                toast.success("CSV yuklab olindi");
              }}
            >
              CSV
            </GhostButton>
            <PrimaryButton onClick={() => window.print()}>PDF / Chop etish</PrimaryButton>
          </>
        }
      />

      <div className="space-y-6 px-5 py-6 lg:px-6">
        <section className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <StatCard label="Bolalar" value={children.filter((c) => c.status === "active").length} />
          <StatCard label="To'langan" value={formatUZS(totalPaid)} tone="primary" />
          <StatCard label="Qarz" value={formatUZS(totalDebt)} tone="warning" />
          <StatCard label="Davomat yozuvlari" value={attendance.length} />
        </section>

        <Panel>
          <PanelHeader
            title={KINDS.find((k) => k.value === kind)!.label}
            subtitle={`${table.rows.length} ta qator · ${periodLabel(period)}`}
            actions={
              <>
                <FilterSelect
                  ariaLabel="Hisobot turi"
                  value={kind}
                  onChange={(v) => setKind(v as ReportKind)}
                  options={KINDS}
                />
                <FilterSelect
                  ariaLabel="Oy"
                  value={period}
                  onChange={setPeriod}
                  options={lastPeriods(12)
                    .slice()
                    .reverse()
                    .map((p) => ({ value: p, label: periodLabel(p) }))}
                />
                <FilterSelect
                  ariaLabel="Guruh"
                  value={groupId}
                  onChange={setGroupId}
                  options={[
                    { value: "all", label: "Guruh: Barchasi" },
                    ...groups.map((g) => ({ value: g.id, label: g.name })),
                  ]}
                />
              </>
            }
          />

          {table.rows.length === 0 ? (
            <EmptyState title="Ma'lumot yo'q" hint="Filtrlarni o'zgartirib ko'ring." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-border/60 text-[11px] uppercase tracking-wider text-muted-foreground">
                    {table.head.map((h) => (
                      <th key={h} className="px-5 py-3 font-medium">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {table.rows.map((r, i) => (
                    <tr key={i} className="hover:bg-primary/5">
                      {r.map((cell, j) => (
                        <td
                          key={j}
                          className={j === 1 ? "px-5 py-3 text-foreground" : "px-5 py-3 text-muted-foreground"}
                        >
                          {cell}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Panel>
      </div>
    </>
  );
}
