import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  attendanceByDateQuery,
  childrenQuery,
  groupsQuery,
  paymentsQuery,
  summarize,
  type Attendance,
  type Child,
} from "@/lib/data";
import {
  currentPeriod,
  formatUZS,
  initials,
  lastPeriods,
  periodLabel,
  todayISO,
} from "@/lib/format";
import { canManageAttendance, canManagePayments, useStaff } from "@/hooks/useAuth";
import {
  EmptyState,
  ErrorNote,
  LoadingRows,
  PageTitle,
  Panel,
  PanelHeader,
  StatCard,
} from "@/components/ui-bits";
import { FilterSelect, SearchInput } from "@/components/form-bits";
import { PaymentModal, ShareBadge, StatusBadge } from "@/components/payment-modal";

export const Route = createFileRoute("/_authenticated/group/$groupId")({
  head: () => ({
    meta: [
      { title: "Guruh sahifasi — Bog'cha tizimi" },
      {
        name: "description",
        content:
          "Guruh bo'yicha bolalar ro'yxati: keldi/kelmadi belgilash, shu oy to'lovi va qarzdorlik.",
      },
      { property: "og:title", content: "Guruh sahifasi — Bog'cha tizimi" },
      {
        property: "og:description",
        content: "Davomat va to'lovlarni bitta jadvalda boshqaring.",
      },
    ],
  }),
  component: GroupPage,
  errorComponent: ({ error }) => <ErrorNote message={(error as Error).message} />,
  notFoundComponent: () => <EmptyState title="Guruh topilmadi" />,
});

const FILTERS = [
  { value: "all", label: "Barchasi" },
  { value: "present", label: "Keldi" },
  { value: "absent", label: "Kelmadi" },
  { value: "paid", label: "To'langan" },
  { value: "partial", label: "Qisman" },
  { value: "unpaid", label: "To'lanmagan" },
  { value: "debt", label: "Qarzdor" },
];

function GroupPage() {
  const { groupId } = Route.useParams();
  const qc = useQueryClient();
  const { data: staff } = useStaff();
  const canMarkAttendance = canManageAttendance(staff?.role);
  const canPay = canManagePayments(staff?.role);

  const [date, setDate] = useState(todayISO());
  const [period, setPeriod] = useState(currentPeriod());
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [payFor, setPayFor] = useState<Child | null>(null);

  const groupsRes = useQuery(groupsQuery());
  const childrenRes = useQuery(childrenQuery());
  const attRes = useQuery(attendanceByDateQuery(date));
  const paymentsRes = useQuery(paymentsQuery());

  const group = (groupsRes.data ?? []).find((g) => g.id === groupId);
  const payments = paymentsRes.data ?? [];

  const byChild = useMemo(() => {
    const map = new Map<string, Attendance>();
    (attRes.data ?? []).forEach((r) => map.set(r.child_id, r));
    return map;
  }, [attRes.data]);

  const kids = useMemo(
    () =>
      (childrenRes.data ?? []).filter(
        (c) => c.group_id === groupId && c.status === "active",
      ),
    [childrenRes.data, groupId],
  );

  const rows = useMemo(
    () =>
      kids.map((c) => {
        const sum = summarize(
          c,
          payments.filter((p) => p.child_id === c.id && p.period_month === period),
        );
        const rec = byChild.get(c.id);
        return { child: c, sum, rec };
      }),
    [kids, payments, period, byChild],
  );

  const visible = rows.filter(({ child, sum, rec }) => {
    if (search && !child.full_name.toLowerCase().includes(search.toLowerCase())) return false;
    switch (filter) {
      case "present":
        return rec?.status === "present" || rec?.status === "late";
      case "absent":
        return rec?.status === "absent";
      case "paid":
        return sum.status === "paid";
      case "partial":
        return sum.status === "partial";
      case "unpaid":
        return sum.status === "unpaid";
      case "debt":
        return sum.debt > 0;
      default:
        return true;
    }
  });

  const present = rows.filter(
    ({ rec }) => rec?.status === "present" || rec?.status === "late",
  ).length;
  const absent = rows.filter(({ rec }) => rec?.status === "absent").length;
  const collected = rows.reduce((s, r) => s + r.sum.paid, 0);
  const totalDebt = rows.reduce((s, r) => s + r.sum.debt, 0);

  const mark = useMutation({
    mutationFn: async ({ childId, status }: { childId: string; status: string }) => {
      const existing = byChild.get(childId);
      const { error } = await supabase.from("attendance").upsert(
        {
          child_id: childId,
          date,
          status,
          check_in:
            status === "absent"
              ? null
              : (existing?.check_in ?? new Date().toTimeString().slice(0, 5)),
          check_out: status === "absent" ? null : (existing?.check_out ?? null),
          note: existing?.note ?? null,
        },
        { onConflict: "child_id,date" },
      );
      if (error) throw new Error(error.message);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["attendance"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const loading = groupsRes.isLoading || childrenRes.isLoading || paymentsRes.isLoading;

  return (
    <>
      <PageTitle
        eyebrow="Guruh boshqaruvi"
        title={`Guruh: ${group?.name ?? "…"}`}
        actions={
          <Link
            to="/children"
            search={{ add: groupId }}
            className="rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground shadow-glow"
          >
            + Bola qo'shish
          </Link>
        }
      />

      <div className="space-y-6 px-5 py-6 lg:px-6">
        <section className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-6">
          <StatCard label="O'qituvchi" value={group?.teacher_name || "—"} />
          <StatCard label="Jami bolalar" value={rows.length} />
          <StatCard label="Bugun kelganlar" value={present} tone="primary" />
          <StatCard label="Bugun kelmaganlar" value={absent} />
          <StatCard label="Shu oy to'lovi" value={formatUZS(collected)} tone="primary" />
          <StatCard label="Shu oy qarzi" value={formatUZS(totalDebt)} tone="warning" />
        </section>

        <Panel>
          <PanelHeader
            title="Bolalar ro'yxati"
            subtitle={`${visible.length} ta bola — ${periodLabel(period)}`}
            actions={
              <>
                <SearchInput value={search} onChange={setSearch} placeholder="Bola qidirish…" />
                <input
                  type="date"
                  aria-label="Davomat sanasi"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="rounded-xl bg-surface px-3 py-2 text-sm text-foreground outline-none ring-1 ring-border/60 focus:ring-primary/50"
                />
                <FilterSelect
                  ariaLabel="Oy"
                  value={period}
                  onChange={setPeriod}
                  options={lastPeriods(12)
                    .slice()
                    .reverse()
                    .map((p) => ({ value: p, label: periodLabel(p) }))}
                />
                <FilterSelect
                  ariaLabel="Filtr"
                  value={filter}
                  onChange={setFilter}
                  options={FILTERS}
                />
              </>
            }
          />

          {loading ? (
            <LoadingRows />
          ) : childrenRes.error ? (
            <ErrorNote message={(childrenRes.error as Error).message} />
          ) : visible.length === 0 ? (
            <EmptyState
              title="Bolalar topilmadi"
              hint="Guruhga bola qo'shing yoki filtrni o'zgartiring."
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[900px] text-left text-sm">
                <thead>
                  <tr className="border-b border-border/60 text-[11px] uppercase tracking-wider text-muted-foreground">
                    <th className="px-4 py-3 font-medium">№</th>
                    <th className="px-4 py-3 font-medium">Bola</th>
                    <th className="px-4 py-3 font-medium">Davomat</th>
                    <th className="px-4 py-3 font-medium">Kelgan vaqti</th>
                    <th className="px-4 py-3 font-medium">Shu oy to'lovi</th>
                    <th className="px-4 py-3 font-medium">Oylik summa</th>
                    <th className="px-4 py-3 font-medium">Qarz</th>
                    <th className="px-4 py-3 font-medium">To'lov holati</th>
                    <th className="px-4 py-3 font-medium">Amallar</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {visible.map(({ child, sum, rec }, i) => {
                    const came = rec?.status === "present" || rec?.status === "late";
                    const away = rec?.status === "absent";
                    return (
                      <tr key={child.id} className="hover:bg-primary/5">
                        <td className="px-4 py-3 text-muted-foreground">{i + 1}</td>
                        <td className="px-4 py-3">
                          <Link
                            to="/children/$childId"
                            params={{ childId: child.id }}
                            className="flex items-center gap-3"
                          >
                            <span className="grid size-9 place-items-center rounded-full bg-primary/12 text-xs font-semibold text-primary ring-1 ring-primary/25">
                              {initials(child.full_name)}
                            </span>
                            <span>
                              <span className="block font-medium text-foreground hover:text-primary">
                                {child.full_name}
                              </span>
                              <span className="block text-[11px] text-muted-foreground">
                                {child.parent_phone || child.child_code}
                              </span>
                            </span>
                          </Link>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex gap-1.5">
                            <button
                              type="button"
                              disabled={!canMarkAttendance || mark.isPending}
                              onClick={() => mark.mutate({ childId: child.id, status: "present" })}
                              className={
                                came
                                  ? "rounded-lg bg-primary px-2.5 py-1 text-[12px] font-semibold text-primary-foreground"
                                  : "rounded-lg px-2.5 py-1 text-[12px] text-muted-foreground ring-1 ring-border/60 hover:text-foreground disabled:opacity-50"
                              }
                            >
                              🟢 Keldi
                            </button>
                            <button
                              type="button"
                              disabled={!canMarkAttendance || mark.isPending}
                              onClick={() => mark.mutate({ childId: child.id, status: "absent" })}
                              className={
                                away
                                  ? "rounded-lg bg-destructive px-2.5 py-1 text-[12px] font-semibold text-destructive-foreground"
                                  : "rounded-lg px-2.5 py-1 text-[12px] text-muted-foreground ring-1 ring-border/60 hover:text-foreground disabled:opacity-50"
                              }
                            >
                              🔴 Kelmadi
                            </button>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-muted-foreground">
                          {rec?.check_in ? rec.check_in.slice(0, 5) : "—"}
                        </td>
                        <td className="px-4 py-3">
                          <ShareBadge required={sum.required} paid={sum.paid} />
                        </td>
                        <td className="px-4 py-3 text-muted-foreground">
                          {formatUZS(sum.required)}
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={
                              sum.debt > 0 ? "font-semibold text-warning" : "text-muted-foreground"
                            }
                          >
                            {formatUZS(sum.debt)}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <StatusBadge status={sum.status} />
                        </td>
                        <td className="px-4 py-3">
                          <button
                            type="button"
                            disabled={!canPay}
                            onClick={() => setPayFor(child)}
                            className="rounded-lg bg-primary/12 px-3 py-1.5 text-[12px] font-medium text-primary ring-1 ring-primary/25 hover:bg-primary/20 disabled:opacity-50"
                          >
                            + To'lov
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </Panel>
      </div>

      <PaymentModal
        child={payFor}
        period={period}
        payments={payments}
        createdBy={staff?.userId ?? null}
        onOpenChange={(v) => !v && setPayFor(null)}
      />
    </>
  );
}
