import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  attendanceByChildQuery,
  childQuery,
  groupsQuery,
  paymentsQuery,
  summarize,
} from "@/lib/data";
import { currentPeriod, formatDate, formatUZS, lastPeriods, periodLabel } from "@/lib/format";
import {
  EmptyState,
  ErrorNote,
  LoadingRows,
  PageTitle,
  Panel,
  PanelHeader,
  Pill,
  StatCard,
} from "@/components/ui-bits";

export const Route = createFileRoute("/_authenticated/children/$childId")({
  head: () => ({
    meta: [
      { title: "Bola profili — Bog'cha tizimi" },
      {
        name: "description",
        content: "Bolaning shaxsiy ma'lumotlari, to'lov tarixi, qarzdorlik va davomati.",
      },
      { property: "og:title", content: "Bola profili — Bog'cha tizimi" },
      { property: "og:description", content: "Bola bo'yicha to'liq ma'lumot." },
    ],
  }),
  component: ChildProfile,
});

const ATT_LABELS: Record<string, string> = {
  present: "Keldi",
  late: "Kechikdi",
  absent: "Kelmadi",
};

function ChildProfile() {
  const { childId } = Route.useParams();
  const childRes = useQuery(childQuery(childId));
  const groupsRes = useQuery(groupsQuery());
  const paymentsRes = useQuery(paymentsQuery());
  const attRes = useQuery(attendanceByChildQuery(childId));

  const child = childRes.data;
  const payments = (paymentsRes.data ?? []).filter((p) => p.child_id === childId);
  const attendance = attRes.data ?? [];

  if (childRes.isLoading) {
    return (
      <>
        <PageTitle title="Bola profili" />
        <div className="p-5">
          <Panel>
            <LoadingRows />
          </Panel>
        </div>
      </>
    );
  }

  if (childRes.error) {
    return (
      <>
        <PageTitle title="Bola profili" />
        <div className="p-5">
          <Panel>
            <ErrorNote message={(childRes.error as Error).message} />
          </Panel>
        </div>
      </>
    );
  }

  if (!child) {
    return (
      <>
        <PageTitle title="Bola profili" />
        <div className="p-5">
          <Panel>
            <EmptyState title="Bola topilmadi" hint="Bu yozuv o'chirilgan bo'lishi mumkin." />
          </Panel>
        </div>
      </>
    );
  }

  const group = (groupsRes.data ?? []).find((g) => g.id === child.group_id);
  const period = currentPeriod();
  const monthSummary = summarize(
    child,
    payments.filter((p) => p.period_month === period),
  );
  const totalPaid = payments.reduce((s, p) => s + Number(p.amount), 0);

  const debtByPeriod = lastPeriods(6)
    .slice()
    .reverse()
    .map((p) => ({
      period: p,
      ...summarize(
        child,
        payments.filter((x) => x.period_month === p),
      ),
    }));

  const presentCount = attendance.filter((a) => a.status === "present").length;

  return (
    <>
      <PageTitle
        eyebrow={`#${child.child_code}`}
        title={child.full_name}
        actions={
          <Link
            to="/children"
            search={{ add: undefined }}
            className="rounded-xl bg-surface px-4 py-2 text-sm text-muted-foreground ring-1 ring-border/60"
          >
            Ro'yxatga qaytish
          </Link>
        }
      />

      <div className="space-y-6 px-5 py-6 lg:px-6">
        <section className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <StatCard label="Oylik to'lov" value={formatUZS(child.monthly_fee)} />
          <StatCard
            label={`${periodLabel(period)} to'langan`}
            value={formatUZS(monthSummary.paid)}
            tone="primary"
          />
          <StatCard label="Joriy qarz" value={formatUZS(monthSummary.debt)} tone="warning" />
          <StatCard label="Jami to'lovlar" value={formatUZS(totalPaid)} />
        </section>

        <section className="grid gap-4 lg:grid-cols-3">
          <Panel>
            <PanelHeader title="Shaxsiy ma'lumotlar" />
            <dl className="space-y-3 p-5 text-sm">
              {[
                ["Tug'ilgan sana", formatDate(child.birth_date)],
                ["Ota-ona", child.parent_name || "—"],
                ["Telefon", child.parent_phone || "—"],
                ["Guruh", group?.name ?? "Guruhsiz"],
                ["Qabul sanasi", formatDate(child.enrollment_date)],
                ["Izoh", child.note || "—"],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between gap-4">
                  <dt className="text-muted-foreground">{k}</dt>
                  <dd className="text-right text-foreground">{v}</dd>
                </div>
              ))}
            </dl>
          </Panel>

          <Panel className="lg:col-span-2">
            <PanelHeader title="Qarzdorlik tarixi" subtitle="So'nggi 6 oy" />
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-border/60 text-[11px] uppercase tracking-wider text-muted-foreground">
                    <th className="px-5 py-3 font-medium">Oy</th>
                    <th className="px-5 py-3 font-medium">Kerak</th>
                    <th className="px-5 py-3 font-medium">To'langan</th>
                    <th className="px-5 py-3 font-medium">Qarz</th>
                    <th className="px-5 py-3 font-medium">Holat</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {debtByPeriod.map((row) => (
                    <tr key={row.period}>
                      <td className="px-5 py-3 text-foreground">{periodLabel(row.period)}</td>
                      <td className="px-5 py-3 text-muted-foreground">
                        {formatUZS(row.required)}
                      </td>
                      <td className="px-5 py-3 text-foreground">{formatUZS(row.paid)}</td>
                      <td className="px-5 py-3 text-foreground">{formatUZS(row.debt)}</td>
                      <td className="px-5 py-3">
                        {row.status === "paid" ? (
                          <Pill tone="primary">To'langan</Pill>
                        ) : row.status === "partial" ? (
                          <Pill tone="warning">Qisman</Pill>
                        ) : (
                          <Pill tone="muted">To'lanmagan</Pill>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>
        </section>

        <section className="grid gap-4 lg:grid-cols-2">
          <Panel>
            <PanelHeader title="To'lov tarixi" subtitle={`${payments.length} ta to'lov`} />
            {payments.length === 0 ? (
              <EmptyState title="To'lov yo'q" />
            ) : (
              <ul className="divide-y divide-border/40">
                {payments.slice(0, 12).map((p) => (
                  <li key={p.id} className="flex items-center justify-between px-5 py-3 text-sm">
                    <div>
                      <p className="text-foreground">{formatUZS(p.amount)}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {periodLabel(p.period_month)} · {p.method}
                      </p>
                    </div>
                    <span className="text-[12px] text-muted-foreground">
                      {formatDate(p.paid_at)}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Panel>

          <Panel>
            <PanelHeader
              title="Davomat tarixi"
              subtitle={`${presentCount} kun kelgan · ${attendance.length} yozuv`}
            />
            {attendance.length === 0 ? (
              <EmptyState title="Davomat yozuvi yo'q" />
            ) : (
              <ul className="divide-y divide-border/40">
                {attendance.slice(0, 12).map((a) => (
                  <li key={a.id} className="flex items-center justify-between px-5 py-3 text-sm">
                    <span className="text-foreground">{formatDate(a.date)}</span>
                    <span className="flex items-center gap-3">
                      <span className="text-[11px] text-muted-foreground">
                        {a.check_in?.slice(0, 5) ?? "—"} – {a.check_out?.slice(0, 5) ?? "—"}
                      </span>
                      <Pill
                        tone={
                          a.status === "present"
                            ? "primary"
                            : a.status === "late"
                              ? "warning"
                              : "muted"
                        }
                      >
                        {ATT_LABELS[a.status] ?? a.status}
                      </Pill>
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Panel>
        </section>
      </div>
    </>
  );
}
