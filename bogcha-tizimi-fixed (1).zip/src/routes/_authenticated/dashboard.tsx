import { createFileRoute, Link } from "@tanstack/react-router";
import { useQueries } from "@tanstack/react-query";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  childrenQuery,
  groupsQuery,
  attendanceByDateQuery,
  attendanceRangeQuery,
  paymentsQuery,
  waitingListQuery,
  notificationsQuery,
  summarize,
} from "@/lib/data";
import {
  currentPeriod,
  formatShortSum,
  formatUZS,
  lastPeriods,
  periodLabel,
  todayISO,
  toISODate,
  UZ_MONTHS_SHORT,
} from "@/lib/format";
import { Panel, PanelHeader, PageTitle, StatCard, EmptyState } from "@/components/ui-bits";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Boshqaruv paneli — Bog'cha tizimi" },
      {
        name: "description",
        content: "Bolalar soni, bugungi davomat, oylik to'lovlar va qarzdorlik statistikasi.",
      },
      { property: "og:title", content: "Boshqaruv paneli — Bog'cha tizimi" },
      { property: "og:description", content: "Bog'cha statistikasi bir ko'rinishda." },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const today = todayISO();
  const period = currentPeriod();
  const weekAgo = toISODate(new Date(Date.now() - 6 * 86400000));

  const results = useQueries({
    queries: [
      childrenQuery(),
      groupsQuery(),
      attendanceByDateQuery(today),
      paymentsQuery(),
      waitingListQuery(),
      attendanceRangeQuery(weekAgo, today),
      notificationsQuery(),
    ],
  });

  const [childrenRes, groupsRes, todayAttRes, paymentsRes, waitingRes, weekAttRes, notifRes] =
    results;
  const loading = results.some((r) => r.isLoading);

  const groups = groupsRes.data ?? [];
  const children = childrenRes.data ?? [];
  const active = children.filter((c) => c.status === "active");
  const todayAtt = todayAttRes.data ?? [];
  const payments = paymentsRes.data ?? [];
  const waiting = waitingRes.data ?? [];
  const weekAtt = weekAttRes.data ?? [];
  const notifications = notifRes.data ?? [];

  const present = todayAtt.filter((a) => a.status === "present").length;
  const late = todayAtt.filter((a) => a.status === "late").length;
  const absent = todayAtt.filter((a) => a.status === "absent").length;

  const monthPayments = payments.filter((p) => p.period_month === period);
  const monthTotal = monthPayments.reduce((s, p) => s + Number(p.amount), 0);

  const summaries = active.map((c) =>
    summarize(
      c,
      monthPayments.filter((p) => p.child_id === c.id),
    ),
  );
  const totalDebt = summaries.reduce((s, x) => s + x.debt, 0);
  const paidCount = summaries.filter((s) => s.status === "paid").length;
  const partialCount = summaries.filter((s) => s.status === "partial").length;
  const unpaidCount = summaries.filter((s) => s.status === "unpaid").length;

  const monthlySeries = lastPeriods(6).map((p) => ({
    name: UZ_MONTHS_SHORT[Number(p.split("-")[1]) - 1],
    total: payments
      .filter((x) => x.period_month === p)
      .reduce((s, x) => s + Number(x.amount), 0),
  }));

  const attendanceSeries = Array.from({ length: 7 }).map((_, i) => {
    const d = toISODate(new Date(Date.now() - (6 - i) * 86400000));
    const rows = weekAtt.filter((a) => a.date === d);
    return {
      name: d.slice(5),
      kelgan: rows.filter((r) => r.status === "present").length,
      kelmagan: rows.filter((r) => r.status === "absent").length,
      kechikkan: rows.filter((r) => r.status === "late").length,
    };
  });

  const pieData = [
    { name: "To'langan", value: paidCount, color: "var(--primary)" },
    { name: "Qisman", value: partialCount, color: "var(--warning)" },
    { name: "To'lanmagan", value: unpaidCount, color: "var(--border)" },
  ];
  const pieTotal = paidCount + partialCount + unpaidCount;

  const attMap = new Map(todayAtt.map((a) => [a.child_id, a.status]));

  const debtByChild = new Map(
    active.map((c) => [
      c.id,
      summarize(
        c,
        monthPayments.filter((p) => p.child_id === c.id),
      ),
    ]),
  );


  return (
    <>
      <PageTitle eyebrow={periodLabel(period)} title="Boshqaruv paneli" />

      <div className="space-y-6 px-5 py-6 lg:px-6">
        <section className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-6">
          <StatCard
            label="Jami bolalar"
            value={loading ? "…" : active.length}
            hint={`${children.length} ta yozuv`}
          />
          <StatCard
            label="Bugun kelganlar"
            value={loading ? "…" : present}
            tone="primary"
            hint={active.length ? `${Math.round((present / active.length) * 100)}%` : "—"}
          />
          <StatCard
            label="Kelmaganlar"
            value={loading ? "…" : absent}
            hint={`${late} kechikkan`}
          />
          <StatCard
            label="Oylik to'lovlar"
            value={loading ? "…" : formatShortSum(monthTotal)}
            hint={`UZS · ${periodLabel(period)}`}
          />
          <StatCard
            label="Qarzdorlik"
            value={loading ? "…" : formatShortSum(totalDebt)}
            tone="warning"
            hint={`${summaries.filter((s) => s.debt > 0).length} bola`}
          />
          <StatCard
            label="Navbatda"
            value={loading ? "…" : waiting.filter((w) => w.status === "waiting").length}
            hint={`${waiting.length} ta ariza`}
          />
        </section>

        <section>
          <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
            <h2 className="font-display text-lg text-foreground">Guruhlar</h2>
            <span className="text-[11px] text-muted-foreground">
              Guruhni tanlang — davomat va to'lovlar shu yerda
            </span>
          </div>
          {groups.length === 0 ? (
            <Panel>
              <EmptyState
                title="Hali guruh ochilmagan"
                hint="Avval «Guruhlar» bo'limidan guruh qo'shing — bolalar shu yerga tushadi."
              />
            </Panel>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {groups.map((g) => {
                const gChildren = active.filter((c) => c.group_id === g.id);
                const pCount = gChildren.filter(
                  (c) => attMap.get(c.id) === "present" || attMap.get(c.id) === "late",
                ).length;
                const aCount = gChildren.filter((c) => attMap.get(c.id) === "absent").length;
                const gPaid = gChildren.reduce(
                  (s, c) => s + (debtByChild.get(c.id)?.paid ?? 0),
                  0,
                );
                const debtors = gChildren.filter(
                  (c) => (debtByChild.get(c.id)?.debt ?? 0) > 0,
                ).length;
                return (
                  <Panel key={g.id} className="p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className="font-display text-xl text-foreground">{g.name}</h3>
                        <p className="text-[12px] text-muted-foreground">
                          O'qituvchi: {g.teacher_name || "—"}
                        </p>
                      </div>
                      <span className="rounded-lg bg-primary/12 px-2.5 py-1 text-[11px] font-medium text-primary ring-1 ring-primary/25">
                        {formatShortSum(g.monthly_fee)}
                      </span>
                    </div>

                    <ul className="mt-4 space-y-1.5 text-sm">
                      <li className="flex justify-between">
                        <span className="text-muted-foreground">👶 Bolalar soni</span>
                        <span className="font-medium text-foreground">{gChildren.length}</span>
                      </li>
                      <li className="flex justify-between">
                        <span className="text-muted-foreground">🟢 Bugun keldi</span>
                        <span className="font-medium text-primary">{pCount}</span>
                      </li>
                      <li className="flex justify-between">
                        <span className="text-muted-foreground">🔴 Bugun kelmadi</span>
                        <span className="font-medium text-destructive">{aCount}</span>
                      </li>
                      <li className="flex justify-between">
                        <span className="text-muted-foreground">💰 Shu oy to'lovlari</span>
                        <span className="font-medium text-foreground">{formatUZS(gPaid)}</span>
                      </li>
                      <li className="flex justify-between">
                        <span className="text-muted-foreground">⚠️ Qarzdorlar</span>
                        <span className="font-medium text-warning">{debtors} ta</span>
                      </li>
                    </ul>

                    <Link
                      to="/group/$groupId"
                      params={{ groupId: g.id }}
                      className="mt-4 flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-glow"
                    >
                      Guruhga kirish →
                    </Link>
                  </Panel>
                );
              })}
            </div>
          )}
        </section>


        <section className="grid gap-4 lg:grid-cols-3">
          <Panel className="lg:col-span-2">
            <PanelHeader
              title="Oylik to'lov statistikasi"
              subtitle="So'nggi 6 oy · UZS"
              actions={
                <span className="rounded-lg bg-primary/12 px-2.5 py-1 text-[11px] font-medium text-primary ring-1 ring-primary/25">
                  Jami {formatShortSum(monthTotal)}
                </span>
              }
            />
            <div className="h-56 p-5">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlySeries}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.4} />
                  <XAxis dataKey="name" stroke="var(--muted-foreground)" fontSize={11} />
                  <YAxis
                    stroke="var(--muted-foreground)"
                    fontSize={11}
                    tickFormatter={(v) => formatShortSum(Number(v))}
                  />
                  <Tooltip
                    contentStyle={{
                      background: "var(--popover)",
                      border: "1px solid var(--border)",
                      borderRadius: 12,
                      color: "var(--foreground)",
                    }}
                    formatter={(v) => formatUZS(Number(v))}
                  />
                  <Bar dataKey="total" fill="var(--primary)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Panel>

          <Panel>
            <PanelHeader title="To'langan / To'lanmagan" subtitle={periodLabel(period)} />
            <div className="flex items-center gap-5 p-5">
              <div className="h-32 w-32 shrink-0">
                {pieTotal > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        dataKey="value"
                        innerRadius={38}
                        outerRadius={58}
                        stroke="none"
                      >
                        {pieData.map((d) => (
                          <Cell key={d.name} fill={d.color} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="grid h-full place-items-center text-xs text-muted-foreground">
                    —
                  </div>
                )}
              </div>
              <div className="space-y-2 text-sm">
                {pieData.map((d) => (
                  <p key={d.name} className="flex items-center gap-2">
                    <span
                      className="size-2.5 rounded-full"
                      style={{ background: d.color }}
                    />
                    {d.name}
                    <span className="ml-auto text-muted-foreground">{d.value}</span>
                  </p>
                ))}
              </div>
            </div>
          </Panel>
        </section>

        <section className="grid gap-4 lg:grid-cols-3">
          <Panel className="lg:col-span-2">
            <PanelHeader title="Davomat statistikasi" subtitle="So'nggi 7 kun" />
            <div className="h-56 p-5">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={attendanceSeries}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" opacity={0.4} />
                  <XAxis dataKey="name" stroke="var(--muted-foreground)" fontSize={11} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={11} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{
                      background: "var(--popover)",
                      border: "1px solid var(--border)",
                      borderRadius: 12,
                      color: "var(--foreground)",
                    }}
                  />
                  <Bar dataKey="kelgan" stackId="a" fill="var(--primary)" radius={[0, 0, 0, 0]} />
                  <Bar dataKey="kechikkan" stackId="a" fill="var(--warning)" />
                  <Bar dataKey="kelmagan" stackId="a" fill="var(--accent)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Panel>

          <Panel>
            <PanelHeader title="Bildirishnomalar" subtitle="So'nggi hodisalar" />
            {notifications.length === 0 ? (
              <EmptyState title="Hozircha bildirishnoma yo'q" />
            ) : (
              <ul className="divide-y divide-border/40">
                {notifications.slice(0, 6).map((n) => (
                  <li key={n.id} className="px-5 py-3">
                    <p className="text-sm text-foreground">{n.title}</p>
                    <p className="text-[11px] text-muted-foreground">{n.message}</p>
                  </li>
                ))}
              </ul>
            )}
          </Panel>
        </section>
      </div>
    </>
  );
}
