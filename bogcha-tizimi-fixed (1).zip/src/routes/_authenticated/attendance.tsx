import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  attendanceByDateQuery,
  childrenQuery,
  groupsQuery,
  paymentsQuery,
  summarize,
  type Attendance,
  type Child,
} from "@/lib/data";
import {
  currentPeriod,
  formatUZS,
  initials,
  lastPeriods,
  periodLabel,
  todayISO,
} from "@/lib/format";
import { canManageAttendance, canManagePayments, useStaff } from "@/hooks/useAuth";
import {
  EmptyState,
  ErrorNote,
  LoadingRows,
  PageTitle,
  Panel,
  PanelHeader,
  StatCard,
} from "@/components/ui-bits";
import { FilterSelect } from "@/components/form-bits";
import { PaymentModal, ShareBadge, StatusBadge } from "@/components/payment-modal";

export const Route = createFileRoute("/_authenticated/attendance")({
  head: () => ({
    meta: [
      { title: "Davomat — Bog'cha tizimi" },
      {
        name: "description",
        content: "Kun va guruh bo'yicha davomat: keldi, kelmadi, kechikdi va kelish vaqti.",
      },
      { property: "og:title", content: "Davomat — Bog'cha tizimi" },
      { property: "og:description", content: "Kundalik davomatni belgilash." },
    ],
  }),
  component: AttendancePage,
});

const STATUSES = [
  { value: "present", label: "Keldi" },
  { value: "late", label: "Kechikdi" },
  { value: "absent", label: "Kelmadi" },
];

function AttendancePage() {
  const qc = useQueryClient();
  const { data: staff } = useStaff();
  const canEdit = canManageAttendance(staff?.role);

  const canPay = canManagePayments(staff?.role);

  const [date, setDate] = useState(todayISO());
  const [groupId, setGroupId] = useState("all");
  const [period, setPeriod] = useState(currentPeriod());
  const [payFor, setPayFor] = useState<Child | null>(null);

  const groupsRes = useQuery(groupsQuery());
  const childrenRes = useQuery(childrenQuery());
  const attRes = useQuery(attendanceByDateQuery(date));
  const paymentsRes = useQuery(paymentsQuery());

  const groups = groupsRes.data ?? [];
  const records = attRes.data ?? [];
  const payments = paymentsRes.data ?? [];

  const rows = useMemo(
    () =>
      (childrenRes.data ?? []).filter(
        (c) => c.status === "active" && (groupId === "all" || c.group_id === groupId),
      ),
    [childrenRes.data, groupId],
  );

  const byChild = useMemo(() => {
    const map = new Map<string, Attendance>();
    records.forEach((r) => map.set(r.child_id, r));
    return map;
  }, [records]);

  const mark = useMutation({
    mutationFn: async (input: {
      childId: string;
      status?: string;
      check_in?: string | null;
      check_out?: string | null;
      note?: string | null;
    }) => {
      const existing = byChild.get(input.childId);
      const payload = {
        child_id: input.childId,
        date,
        status: input.status ?? existing?.status ?? "present",
        check_in: input.check_in !== undefined ? input.check_in : (existing?.check_in ?? null),
        check_out:
          input.check_out !== undefined ? input.check_out : (existing?.check_out ?? null),
        note: input.note !== undefined ? input.note : (existing?.note ?? null),
      };
      const { error } = await supabase
        .from("attendance")
        .upsert(payload, { onConflict: "child_id,date" });
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["attendance"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const present = rows.filter((c) => byChild.get(c.id)?.status === "present").length;
  const late = rows.filter((c) => byChild.get(c.id)?.status === "late").length;
  const absent = rows.filter((c) => byChild.get(c.id)?.status === "absent").length;
  const unmarked = rows.length - present - late - absent;

  return (
    <>
      <PageTitle eyebrow="Kundalik jurnal" title="Davomat" />

      <div className="space-y-6 px-5 py-6 lg:px-6">
        <section className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <StatCard label="Keldi" value={present} tone="primary" />
          <StatCard label="Kechikdi" value={late} tone="warning" />
          <StatCard label="Kelmadi" value={absent} />
          <StatCard label="Belgilanmagan" value={unmarked} />
        </section>

        <Panel>
          <PanelHeader
            title="Davomat jadvali"
            subtitle={`${rows.length} ta bola`}
            actions={
              <>
                <input
                  type="date"
                  aria-label="Sana"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="rounded-xl bg-surface px-3 py-2 text-sm text-foreground outline-none ring-1 ring-border/60 focus:ring-primary/50"
                />
                <FilterSelect
                  ariaLabel="Guruh"
                  value={groupId}
                  onChange={setGroupId}
                  options={[
                    { value: "all", label: "Guruh: Barchasi" },
                    ...groups.map((g) => ({ value: g.id, label: g.name })),
                  ]}
                />
                <FilterSelect
                  ariaLabel="To'lov oyi"
                  value={period}
                  onChange={setPeriod}
                  options={lastPeriods(12)
                    .slice()
                    .reverse()
                    .map((p) => ({ value: p, label: periodLabel(p) }))}
                />
              </>
            }
          />

          {childrenRes.isLoading || attRes.isLoading ? (
            <LoadingRows />
          ) : attRes.error ? (
            <ErrorNote message={(attRes.error as Error).message} />
          ) : rows.length === 0 ? (
            <EmptyState title="Bu guruhda faol bola yo'q" />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-border/60 text-[11px] uppercase tracking-wider text-muted-foreground">
                    <th className="px-5 py-3 font-medium">Bola</th>
                    <th className="px-5 py-3 font-medium">Holat</th>
                    <th className="hidden px-5 py-3 font-medium sm:table-cell">Kelgan vaqti</th>
                    <th className="hidden px-5 py-3 font-medium sm:table-cell">Ketgan vaqti</th>
                    <th className="hidden px-5 py-3 font-medium lg:table-cell">Izoh</th>
                    <th className="px-5 py-3 font-medium">Shu oy to'lovi</th>
                    <th className="hidden px-5 py-3 font-medium md:table-cell">Qarz</th>
                    <th className="px-5 py-3 font-medium">To'lov holati</th>
                    <th className="px-5 py-3 font-medium">Amallar</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {rows.map((c) => {
                    const rec = byChild.get(c.id);
                    const sum = summarize(
                      c,
                      payments.filter(
                        (p) => p.child_id === c.id && p.period_month === period,
                      ),
                    );
                    const group = groups.find((g) => g.id === c.group_id);
                    return (
                      <tr key={c.id} className="hover:bg-primary/5">
                        <td className="px-5 py-3">
                          <div className="flex items-center gap-3">
                            <div className="grid size-9 place-items-center rounded-full bg-primary/12 text-xs font-semibold text-primary ring-1 ring-primary/25">
                              {initials(c.full_name)}
                            </div>
                            <div>
                              <p className="font-medium text-foreground">{c.full_name}</p>
                              <p className="text-[11px] text-muted-foreground">
                                {group?.name ?? "Guruhsiz"}
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="px-5 py-3">
                          <div className="flex gap-1">
                            {STATUSES.map((s) => {
                              const active = rec?.status === s.value;
                              return (
                                <button
                                  key={s.value}
                                  type="button"
                                  disabled={!canEdit || mark.isPending}
                                  onClick={() =>
                                    mark.mutate({
                                      childId: c.id,
                                      status: s.value,
                                      check_in:
                                        s.value !== "absent" && !rec?.check_in
                                          ? new Date().toTimeString().slice(0, 5)
                                          : rec?.check_in ?? null,
                                    })
                                  }
                                  className={
                                    active
                                      ? "rounded-lg bg-primary px-2.5 py-1 text-[12px] font-medium text-primary-foreground"
                                      : "rounded-lg px-2.5 py-1 text-[12px] text-muted-foreground ring-1 ring-border/60 hover:text-foreground disabled:opacity-50"
                                  }
                                >
                                  {s.label}
                                </button>
                              );
                            })}
                          </div>
                        </td>
                        <td className="hidden px-5 py-3 sm:table-cell">
                          <input
                            type="time"
                            disabled={!canEdit}
                            value={rec?.check_in?.slice(0, 5) ?? ""}
                            onChange={(e) =>
                              mark.mutate({ childId: c.id, check_in: e.target.value || null })
                            }
                            className="rounded-lg bg-surface px-2 py-1 text-[12px] text-foreground outline-none ring-1 ring-border/60"
                          />
                        </td>
                        <td className="hidden px-5 py-3 sm:table-cell">
                          <input
                            type="time"
                            disabled={!canEdit}
                            value={rec?.check_out?.slice(0, 5) ?? ""}
                            onChange={(e) =>
                              mark.mutate({ childId: c.id, check_out: e.target.value || null })
                            }
                            className="rounded-lg bg-surface px-2 py-1 text-[12px] text-foreground outline-none ring-1 ring-border/60"
                          />
                        </td>
                        <td className="hidden px-5 py-3 lg:table-cell">
                          <input
                            disabled={!canEdit}
                            defaultValue={rec?.note ?? ""}
                            placeholder="Izoh…"
                            onBlur={(e) =>
                              mark.mutate({ childId: c.id, note: e.target.value || null })
                            }
                            className="w-40 rounded-lg bg-surface px-2 py-1 text-[12px] text-foreground outline-none ring-1 ring-border/60 placeholder:text-muted-foreground/70"
                          />
                        </td>
                        <td className="px-5 py-3">
                          <ShareBadge required={sum.required} paid={sum.paid} />
                        </td>
                        <td className="hidden px-5 py-3 md:table-cell">
                          <span
                            className={
                              sum.debt > 0 ? "font-semibold text-warning" : "text-muted-foreground"
                            }
                          >
                            {formatUZS(sum.debt)}
                          </span>
                        </td>
                        <td className="px-5 py-3">
                          <StatusBadge status={sum.status} />
                        </td>
                        <td className="px-5 py-3">
                          <button
                            type="button"
                            disabled={!canPay}
                            onClick={() => setPayFor(c)}
                            className="rounded-lg bg-primary/12 px-3 py-1.5 text-[12px] font-medium text-primary ring-1 ring-primary/25 hover:bg-primary/20 disabled:opacity-50"
                          >
                            + To'lov
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </Panel>
      </div>

      <PaymentModal
        child={payFor}
        period={period}
        payments={payments}
        createdBy={staff?.userId ?? null}
        onOpenChange={(v) => !v && setPayFor(null)}
      />
    </>
  );
}
