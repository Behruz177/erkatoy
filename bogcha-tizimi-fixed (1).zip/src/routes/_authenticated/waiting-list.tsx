import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { z } from "zod";
import { ArrowDown, ArrowUp } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { groupsQuery, notify, waitingListQuery, type WaitingItem } from "@/lib/data";
import { formatDate, todayISO } from "@/lib/format";
import { canManageChildren, useStaff } from "@/hooks/useAuth";
import {
  EmptyState,
  ErrorNote,
  LoadingRows,
  PageTitle,
  Panel,
  PanelHeader,
  Pill,
  StatCard,
} from "@/components/ui-bits";
import {
  ConfirmDialog,
  FilterSelect,
  FormModal,
  GhostButton,
  PrimaryButton,
  SelectField,
  TextField,
} from "@/components/form-bits";

export const Route = createFileRoute("/_authenticated/waiting-list")({
  head: () => ({
    meta: [
      { title: "Navbat — Bog'cha tizimi" },
      {
        name: "description",
        content: "Navbatdagi arizalar: tartib raqami, holat va guruh so'rovi.",
      },
      { property: "og:title", content: "Navbat — Bog'cha tizimi" },
      { property: "og:description", content: "Navbat ro'yxatini boshqarish." },
    ],
  }),
  component: WaitingPage,
});

const WAITING_STATUS: Record<string, string> = {
  waiting: "Navbatda",
  contacted: "Bog'lanildi",
  accepted: "Qabul qilindi",
  rejected: "Rad etildi",
};

const schema = z.object({
  full_name: z.string().trim().min(2, "Ism kamida 2 belgi").max(100),
  parent_name: z.string().trim().max(100),
  parent_phone: z.string().trim().max(30),
});

const empty = {
  full_name: "",
  birth_date: "",
  parent_name: "",
  parent_phone: "",
  applied_date: todayISO(),
  requested_group_id: "",
  status: "waiting",
  notes: "",
};

function WaitingPage() {
  const qc = useQueryClient();
  const { data: staff } = useStaff();
  const canEdit = canManageChildren(staff?.role);

  const waitingRes = useQuery(waitingListQuery());
  const groupsRes = useQuery(groupsQuery());
  const groups = groupsRes.data ?? [];

  const [statusFilter, setStatusFilter] = useState("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<WaitingItem | null>(null);
  const [form, setForm] = useState(empty);
  const [deleting, setDeleting] = useState<WaitingItem | null>(null);

  const rows = useMemo(
    () =>
      (waitingRes.data ?? []).filter(
        (w) => statusFilter === "all" || w.status === statusFilter,
      ),
    [waitingRes.data, statusFilter],
  );

  const save = useMutation({
    mutationFn: async () => {
      const parsed = schema.safeParse({
        full_name: form.full_name,
        parent_name: form.parent_name,
        parent_phone: form.parent_phone,
      });
      if (!parsed.success) throw new Error(parsed.error.issues[0]!.message);
      const payload = {
        full_name: parsed.data.full_name,
        birth_date: form.birth_date || null,
        parent_name: parsed.data.parent_name,
        parent_phone: parsed.data.parent_phone,
        applied_date: form.applied_date || todayISO(),
        requested_group_id: form.requested_group_id || null,
        status: form.status,
        notes: form.notes || null,
      };
      if (editing) {
        const { error } = await supabase
          .from("waiting_list")
          .update(payload)
          .eq("id", editing.id);
        if (error) throw new Error(error.message);
      } else {
        const { error } = await supabase.from("waiting_list").insert(payload);
        if (error) throw new Error(error.message);
        await notify(
          "waiting",
          "Yangi ariza",
          `${payload.full_name} navbat ro'yxatiga qo'shildi`,
        );
      }
    },
    onSuccess: () => {
      toast.success(editing ? "Ariza yangilandi" : "Ariza qo'shildi");
      setOpen(false);
      setEditing(null);
      qc.invalidateQueries({ queryKey: ["waiting_list"] });
      qc.invalidateQueries({ queryKey: ["notifications"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const accept = useMutation({
    mutationFn: async (w: WaitingItem) => {
      const group = groups.find((g) => g.id === w.requested_group_id);
      const { data, error } = await supabase
        .from("children")
        .insert({
          full_name: w.full_name,
          birth_date: w.birth_date,
          parent_name: w.parent_name,
          parent_phone: w.parent_phone,
          group_id: w.requested_group_id,
          monthly_fee: group?.monthly_fee ?? 0,
          enrollment_date: todayISO(),
          status: "active",
        })
        .select("id")
        .single();
      if (error) throw new Error(error.message);
      const { error: upErr } = await supabase
        .from("waiting_list")
        .update({ status: "accepted" })
        .eq("id", w.id);
      if (upErr) throw new Error(upErr.message);
      await notify("child", "Yangi bola qabul qilindi", `${w.full_name} bog'chaga qabul qilindi`, data?.id);
    },
    onSuccess: () => {
      toast.success("Bola ro'yxatga o'tkazildi");
      qc.invalidateQueries({ queryKey: ["waiting_list"] });
      qc.invalidateQueries({ queryKey: ["children"] });
      qc.invalidateQueries({ queryKey: ["notifications"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (w: WaitingItem) => {
      const { error } = await supabase.from("waiting_list").delete().eq("id", w.id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      toast.success("Ariza o'chirildi");
      setDeleting(null);
      qc.invalidateQueries({ queryKey: ["waiting_list"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const all = waitingRes.data ?? [];

  const move = useMutation({
    mutationFn: async ({ item, direction }: { item: WaitingItem; direction: "up" | "down" }) => {
      const idx = all.findIndex((w) => w.id === item.id);
      const neighbor = all[direction === "up" ? idx - 1 : idx + 1];
      if (!neighbor) return;
      const { error: e1 } = await supabase
        .from("waiting_list")
        .update({ position: neighbor.position })
        .eq("id", item.id);
      if (e1) throw new Error(e1.message);
      const { error: e2 } = await supabase
        .from("waiting_list")
        .update({ position: item.position })
        .eq("id", neighbor.id);
      if (e2) throw new Error(e2.message);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["waiting_list"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <>
      <PageTitle
        eyebrow={`${all.length} ta ariza`}
        title="Navbat ro'yxati"
        actions={
          canEdit ? (
            <PrimaryButton
              onClick={() => {
                setEditing(null);
                setForm(empty);
                setOpen(true);
              }}
            >
              Ariza qo'shish
            </PrimaryButton>
          ) : null
        }
      />

      <div className="space-y-6 px-5 py-6 lg:px-6">
        <section className="grid grid-cols-2 gap-4 md:grid-cols-4">
          <StatCard
            label="Navbatda"
            value={all.filter((w) => w.status === "waiting").length}
            tone="primary"
          />
          <StatCard
            label="Bog'lanildi"
            value={all.filter((w) => w.status === "contacted").length}
          />
          <StatCard
            label="Qabul qilindi"
            value={all.filter((w) => w.status === "accepted").length}
          />
          <StatCard
            label="Rad etildi"
            value={all.filter((w) => w.status === "rejected").length}
          />
        </section>

        <Panel>
          <PanelHeader
            title="Arizalar"
            subtitle={`${rows.length} ta ko'rsatilmoqda`}
            actions={
              <FilterSelect
                ariaLabel="Holat"
                value={statusFilter}
                onChange={setStatusFilter}
                options={[
                  { value: "all", label: "Holat: Barchasi" },
                  ...Object.entries(WAITING_STATUS).map(([value, label]) => ({ value, label })),
                ]}
              />
            }
          />

          {waitingRes.isLoading ? (
            <LoadingRows />
          ) : waitingRes.error ? (
            <ErrorNote message={(waitingRes.error as Error).message} />
          ) : rows.length === 0 ? (
            <EmptyState title="Ariza yo'q" hint="Yangi ariza qo'shing." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-border/60 text-[11px] uppercase tracking-wider text-muted-foreground">
                    <th className="px-5 py-3 font-medium">#</th>
                    <th className="px-5 py-3 font-medium">Bola</th>
                    <th className="hidden px-5 py-3 font-medium md:table-cell">Ota-ona</th>
                    <th className="hidden px-5 py-3 font-medium sm:table-cell">Telefon</th>
                    <th className="hidden px-5 py-3 font-medium lg:table-cell">Ariza sanasi</th>
                    <th className="px-5 py-3 font-medium">Guruh</th>
                    <th className="px-5 py-3 font-medium">Holat</th>
                    <th className="px-5 py-3 text-right font-medium">Amallar</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {rows.map((w) => (
                    <tr key={w.id} className="hover:bg-primary/5">
                      <td className="px-5 py-3 text-muted-foreground">{w.position}</td>
                      <td className="px-5 py-3">
                        <p className="font-medium text-foreground">{w.full_name}</p>
                        <p className="text-[11px] text-muted-foreground">
                          {formatDate(w.birth_date)}
                        </p>
                      </td>
                      <td className="hidden px-5 py-3 text-muted-foreground md:table-cell">
                        {w.parent_name || "—"}
                      </td>
                      <td className="hidden px-5 py-3 text-muted-foreground sm:table-cell">
                        {w.parent_phone || "—"}
                      </td>
                      <td className="hidden px-5 py-3 text-muted-foreground lg:table-cell">
                        {formatDate(w.applied_date)}
                      </td>
                      <td className="px-5 py-3 text-muted-foreground">
                        {groups.find((g) => g.id === w.requested_group_id)?.name ?? "—"}
                      </td>
                      <td className="px-5 py-3">
                        <Pill
                          tone={
                            w.status === "accepted"
                              ? "primary"
                              : w.status === "rejected"
                                ? "muted"
                                : "warning"
                          }
                        >
                          {WAITING_STATUS[w.status] ?? w.status}
                        </Pill>
                      </td>
                      <td className="px-5 py-3 text-right">
                        {canEdit ? (
                          <div className="flex justify-end gap-1">
                            <GhostButton
                              aria-label="Yuqoriga"
                              disabled={all.findIndex((x) => x.id === w.id) === 0 || move.isPending}
                              onClick={() => move.mutate({ item: w, direction: "up" })}
                            >
                              <ArrowUp className="size-3.5" />
                            </GhostButton>
                            <GhostButton
                              aria-label="Pastga"
                              disabled={
                                all.findIndex((x) => x.id === w.id) === all.length - 1 ||
                                move.isPending
                              }
                              onClick={() => move.mutate({ item: w, direction: "down" })}
                            >
                              <ArrowDown className="size-3.5" />
                            </GhostButton>
                            {w.status !== "accepted" ? (
                              <GhostButton onClick={() => accept.mutate(w)}>
                                Qabul qilish
                              </GhostButton>
                            ) : null}
                            <GhostButton
                              onClick={() => {
                                setEditing(w);
                                setForm({
                                  full_name: w.full_name,
                                  birth_date: w.birth_date ?? "",
                                  parent_name: w.parent_name ?? "",
                                  parent_phone: w.parent_phone ?? "",
                                  applied_date: w.applied_date,
                                  requested_group_id: w.requested_group_id ?? "",
                                  status: w.status,
                                  notes: w.notes ?? "",
                                });
                                setOpen(true);
                              }}
                            >
                              Tahrirlash
                            </GhostButton>
                            <GhostButton onClick={() => setDeleting(w)}>O'chirish</GhostButton>
                          </div>
                        ) : null}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Panel>
      </div>

      <FormModal
        open={open}
        onOpenChange={setOpen}
        title={editing ? "Arizani tahrirlash" : "Yangi ariza"}
        submitting={save.isPending}
        onSubmit={() => save.mutate()}
      >
        <TextField
          label="Bola ismi"
          required
          value={form.full_name}
          onChange={(v) => setForm({ ...form, full_name: v })}
        />
        <div className="grid gap-3 sm:grid-cols-2">
          <TextField
            label="Tug'ilgan sana"
            type="date"
            value={form.birth_date}
            onChange={(v) => setForm({ ...form, birth_date: v })}
          />
          <TextField
            label="Ariza sanasi"
            type="date"
            value={form.applied_date}
            onChange={(v) => setForm({ ...form, applied_date: v })}
          />
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <TextField
            label="Ota-ona ismi"
            value={form.parent_name}
            onChange={(v) => setForm({ ...form, parent_name: v })}
          />
          <TextField
            label="Telefon"
            value={form.parent_phone}
            onChange={(v) => setForm({ ...form, parent_phone: v })}
          />
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <SelectField
            label="So'ralgan guruh"
            value={form.requested_group_id}
            onChange={(v) => setForm({ ...form, requested_group_id: v })}
            options={[
              { value: "", label: "Tanlanmagan" },
              ...groups.map((g) => ({ value: g.id, label: g.name })),
            ]}
          />
          <SelectField
            label="Holat"
            value={form.status}
            onChange={(v) => setForm({ ...form, status: v })}
            options={Object.entries(WAITING_STATUS).map(([value, label]) => ({ value, label }))}
          />
        </div>
        <TextField
          label="Izoh"
          value={form.notes}
          onChange={(v) => setForm({ ...form, notes: v })}
        />
      </FormModal>

      <ConfirmDialog
        open={deleting !== null}
        onOpenChange={(v) => !v && setDeleting(null)}
        title="Arizani o'chirish"
        description={`${deleting?.full_name ?? ""} arizasi o'chiriladi.`}
        onConfirm={() => deleting && remove.mutate(deleting)}
      />
    </>
  );
}
