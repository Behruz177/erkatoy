import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { notificationsQuery } from "@/lib/data";
import { ROLE_LABELS, useStaff } from "@/hooks/useAuth";
import { formatDate } from "@/lib/format";
import {
  EmptyState,
  PageTitle,
  Panel,
  PanelHeader,
  Pill,
} from "@/components/ui-bits";
import { GhostButton, PrimaryButton, TextField } from "@/components/form-bits";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({
    meta: [
      { title: "Sozlamalar — Bog'cha tizimi" },
      {
        name: "description",
        content: "Profil ma'lumotlari, rol va bildirishnomalarni boshqarish.",
      },
      { property: "og:title", content: "Sozlamalar — Bog'cha tizimi" },
      { property: "og:description", content: "Hisob sozlamalari." },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const { data: staff } = useStaff();
  const notifRes = useQuery(notificationsQuery());
  const [fullName, setFullName] = useState("");

  useEffect(() => {
    if (staff?.fullName) setFullName(staff.fullName);
  }, [staff?.fullName]);

  const saveProfile = useMutation({
    mutationFn: async () => {
      const parsed = z
        .string()
        .trim()
        .min(2, "Ism kamida 2 belgi")
        .max(80)
        .safeParse(fullName);
      if (!parsed.success) throw new Error(parsed.error.issues[0]!.message);
      if (!staff) throw new Error("Sessiya topilmadi");
      const { error } = await supabase
        .from("profiles")
        .update({ full_name: parsed.data })
        .eq("user_id", staff.userId);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      toast.success("Profil saqlandi");
      qc.invalidateQueries({ queryKey: ["staff-session"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const markRead = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("notifications")
        .update({ is_read: true })
        .eq("id", id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["notifications"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  const notifications = notifRes.data ?? [];

  return (
    <>
      <PageTitle eyebrow="Hisob" title="Sozlamalar" />

      <div className="grid gap-4 px-5 py-6 lg:grid-cols-2 lg:px-6">
        <Panel>
          <PanelHeader title="Profil" subtitle={staff?.email ?? ""} />
          <div className="space-y-4 p-5">
            <TextField label="To'liq ism" value={fullName} onChange={setFullName} />
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Rol</span>
              <Pill tone="primary">{staff ? ROLE_LABELS[staff.role] : "—"}</Pill>
            </div>
            <div className="flex gap-2">
              <PrimaryButton onClick={() => saveProfile.mutate()}>Saqlash</PrimaryButton>
              <GhostButton onClick={signOut}>Chiqish</GhostButton>
            </div>
          </div>
        </Panel>

        <Panel>
          <PanelHeader
            title="Bildirishnomalar"
            subtitle={`${notifications.filter((n) => !n.is_read).length} ta o'qilmagan`}
          />
          {notifications.length === 0 ? (
            <EmptyState title="Bildirishnoma yo'q" />
          ) : (
            <ul className="max-h-[420px] divide-y divide-border/40 overflow-y-auto">
              {notifications.map((n) => (
                <li key={n.id} className="flex items-start justify-between gap-3 px-5 py-3">
                  <div>
                    <p className="text-sm text-foreground">{n.title}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {n.message} · {formatDate(n.created_at)}
                    </p>
                  </div>
                  {n.is_read ? (
                    <span className="text-[11px] text-muted-foreground">O'qilgan</span>
                  ) : (
                    <GhostButton onClick={() => markRead.mutate(n.id)}>O'qildi</GhostButton>
                  )}
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
    </>
  );
}
