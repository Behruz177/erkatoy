import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { childrenQuery, groupsQuery, paymentsQuery, summarize } from "@/lib/data";
import {
  currentPeriod,
  downloadCSV,
  formatDate,
  formatUZS,
  lastPeriods,
  periodLabel,
} from "@/lib/format";
import {
  EmptyState,
  ErrorNote,
  LoadingRows,
  PageTitle,
  Panel,
  PanelHeader,
  StatCard,
} from "@/components/ui-bits";
import { FilterSelect, GhostButton } from "@/components/form-bits";

export const Route = createFileRoute("/_authenticated/debts")({
  head: () => ({
    meta: [
      { title: "Qarzdorlik — Bog'cha tizimi" },
      {
        name: "description",
        content: "Qarzdor bolalar ro'yxati, umumiy qarz summasi va oxirgi to'lov sanalari.",
      },
      { property: "og:title", content: "Qarzdorlik — Bog'cha tizimi" },
      { property: "og:description", content: "Qarzdorlikni nazorat qilish." },
    ],
  }),
  component: DebtsPage,
});

function DebtsPage() {
  const [period, setPeriod] = useState(currentPeriod());
  const [groupId, setGroupId] = useState("all");
  const [minDebt, setMinDebt] = useState("0");

  const childrenRes = useQuery(childrenQuery());
  const groupsRes = useQuery(groupsQuery());
  const paymentsRes = useQuery(paymentsQuery());

  const groups = groupsRes.data ?? [];
  const periodPayments = (paymentsRes.data ?? []).filter((p) => p.period_month === period);

  const rows = useMemo(
    () =>
      (childrenRes.data ?? [])
        .filter((c) => c.status === "active")
        .filter((c) => groupId === "all" || c.group_id === groupId)
        .map((c) => ({
          child: c,
          summary: summarize(
            c,
            periodPayments.filter((p) => p.child_id === c.id),
          ),
        }))
        .filter((r) => r.summary.debt > 0)
        .filter((r) => r.summary.debt >= Number(minDebt))
        .sort((a, b) => b.summary.debt - a.summary.debt),
    [childrenRes.data, periodPayments, groupId, minDebt],
  );

  const total = rows.reduce((s, r) => s + r.summary.debt, 0);

  return (
    <>
      <PageTitle
        eyebrow={periodLabel(period)}
        title="Qarzdorlik"
        actions={
          <GhostButton
            onClick={() =>
              downloadCSV(`qarzdorlik-${period}.csv`, [
                ["Bola", "Ota-ona", "Telefon", "Oylik to'lov", "To'langan", "Qarz", "So'nggi to'lov"],
                ...rows.map((r) => [
                  r.child.full_name,
                  r.child.parent_name,
                  r.child.parent_phone,
                  r.summary.required,
                  r.summary.paid,
                  r.summary.debt,
                  r.summary.lastPaidAt ?? "",
                ]),
              ])
            }
          >
            CSV yuklab olish
          </GhostButton>
        }
      />

      <div className="space-y-6 px-5 py-6 lg:px-6">
        <section className="grid grid-cols-2 gap-4 md:grid-cols-3">
          <StatCard label="Umumiy qarz" value={formatUZS(total)} tone="warning" />
          <StatCard label="Qarzdor bolalar" value={rows.length} />
          <StatCard
            label="O'rtacha qarz"
            value={formatUZS(rows.length ? Math.round(total / rows.length) : 0)}
          />
        </section>

        <Panel>
          <PanelHeader
            title="Qarzdorlar ro'yxati"
            subtitle={periodLabel(period)}
            actions={
              <>
                <FilterSelect
                  ariaLabel="Oy"
                  value={period}
                  onChange={setPeriod}
                  options={lastPeriods(12)
                    .slice()
                    .reverse()
                    .map((p) => ({ value: p, label: periodLabel(p) }))}
                />
                <FilterSelect
                  ariaLabel="Guruh"
                  value={groupId}
                  onChange={setGroupId}
                  options={[
                    { value: "all", label: "Guruh: Barchasi" },
                    ...groups.map((g) => ({ value: g.id, label: g.name })),
                  ]}
                />
                <FilterSelect
                  ariaLabel="Qarz miqdori"
                  value={minDebt}
                  onChange={setMinDebt}
                  options={[
                    { value: "0", label: "Qarz: Barchasi" },
                    { value: "100000", label: "100 000+ so'm" },
                    { value: "500000", label: "500 000+ so'm" },
                    { value: "1000000", label: "1 000 000+ so'm" },
                  ]}
                />
              </>
            }
          />

          {childrenRes.isLoading || paymentsRes.isLoading ? (
            <LoadingRows />
          ) : paymentsRes.error ? (
            <ErrorNote message={(paymentsRes.error as Error).message} />
          ) : rows.length === 0 ? (
            <EmptyState title="Qarzdorlik yo'q" hint="Barcha to'lovlar to'liq amalga oshirilgan." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-border/60 text-[11px] uppercase tracking-wider text-muted-foreground">
                    <th className="px-5 py-3 font-medium">Bola</th>
                    <th className="hidden px-5 py-3 font-medium md:table-cell">Ota-ona</th>
                    <th className="hidden px-5 py-3 font-medium sm:table-cell">Telefon</th>
                    <th className="px-5 py-3 font-medium">Oylik</th>
                    <th className="px-5 py-3 font-medium">To'langan</th>
                    <th className="px-5 py-3 font-medium">Qarz</th>
                    <th className="hidden px-5 py-3 font-medium lg:table-cell">
                      So'nggi to'lov
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {rows.map(({ child, summary }) => (
                    <tr key={child.id} className="hover:bg-primary/5">
                      <td className="px-5 py-3">
                        <p className="font-medium text-foreground">{child.full_name}</p>
                        <p className="text-[11px] text-muted-foreground">
                          {groups.find((g) => g.id === child.group_id)?.name ?? "Guruhsiz"}
                        </p>
                      </td>
                      <td className="hidden px-5 py-3 text-muted-foreground md:table-cell">
                        {child.parent_name || "—"}
                      </td>
                      <td className="hidden px-5 py-3 text-muted-foreground sm:table-cell">
                        {child.parent_phone || "—"}
                      </td>
                      <td className="px-5 py-3 text-muted-foreground">
                        {formatUZS(summary.required)}
                      </td>
                      <td className="px-5 py-3 text-foreground">{formatUZS(summary.paid)}</td>
                      <td className="px-5 py-3 font-semibold text-warning">
                        {formatUZS(summary.debt)}
                      </td>
                      <td className="hidden px-5 py-3 text-muted-foreground lg:table-cell">
                        {formatDate(summary.lastPaidAt)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Panel>
      </div>
    </>
  );
}
