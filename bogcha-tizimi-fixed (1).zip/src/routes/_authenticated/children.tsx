import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import {
  childrenQuery,
  groupsQuery,
  paymentsQuery,
  summarize,
  notify,
  type Child,
} from "@/lib/data";
import { currentPeriod, formatDate, formatUZS, initials, todayISO } from "@/lib/format";
import { canManageChildren, useStaff } from "@/hooks/useAuth";
import {
  EmptyState,
  ErrorNote,
  LoadingRows,
  PageTitle,
  Panel,
  PanelHeader,
  Pill,
} from "@/components/ui-bits";
import {
  ConfirmDialog,
  FilterSelect,
  FormModal,
  GhostButton,
  PrimaryButton,
  SearchInput,
  SelectField,
  TextField,
} from "@/components/form-bits";

export const Route = createFileRoute("/_authenticated/children")({
  validateSearch: (search: Record<string, unknown>) => ({
    add: typeof search["add"] === "string" ? (search["add"] as string) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Bolalar — Bog'cha tizimi" },
      {
        name: "description",
        content: "Bolalar ro'yxati: qidiruv, guruh va holat bo'yicha filtrlash, tahrirlash.",
      },
      { property: "og:title", content: "Bolalar — Bog'cha tizimi" },
      { property: "og:description", content: "Bolalar ro'yxatini boshqarish." },
    ],
  }),
  component: ChildrenPage,
});

export const STATUS_LABELS: Record<string, string> = {
  active: "Faol",
  waiting: "Navbatda",
  left: "Chiqib ketgan",
};

const childSchema = z.object({
  full_name: z.string().trim().min(2, "Ism kamida 2 belgi").max(100),
  parent_name: z.string().trim().max(100),
  parent_phone: z.string().trim().max(30),
  group_id: z.string().min(1, "Qaysi guruhga qo'yilishini tanlang"),
  monthly_fee: z.number().min(0).max(100_000_000),
});

interface FormState {
  full_name: string;
  birth_date: string;
  parent_name: string;
  parent_phone: string;
  group_id: string;
  monthly_fee: string;
  enrollment_date: string;
  status: string;
  note: string;
}

const emptyForm: FormState = {
  full_name: "",
  birth_date: "",
  parent_name: "",
  parent_phone: "",
  group_id: "",
  monthly_fee: "0",
  enrollment_date: todayISO(),
  status: "active",
  note: "",
};

function ChildrenPage() {
  const qc = useQueryClient();
  const { data: staff } = useStaff();
  const canEdit = canManageChildren(staff?.role);
  const { add } = Route.useSearch();
  const navigate = Route.useNavigate();

  const childrenRes = useQuery(childrenQuery());
  const groupsRes = useQuery(groupsQuery());
  const paymentsRes = useQuery(paymentsQuery());

  const [search, setSearch] = useState("");
  const [groupFilter, setGroupFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Child | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [deleting, setDeleting] = useState<Child | null>(null);

  const groups = groupsRes.data ?? [];
  const period = currentPeriod();
  const monthPayments = (paymentsRes.data ?? []).filter((p) => p.period_month === period);

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return (childrenRes.data ?? []).filter((c) => {
      if (groupFilter !== "all" && c.group_id !== groupFilter) return false;
      if (statusFilter !== "all" && c.status !== statusFilter) return false;
      if (!q) return true;
      return (
        c.full_name.toLowerCase().includes(q) ||
        (c.parent_phone ?? "").toLowerCase().includes(q) ||
        (c.parent_name ?? "").toLowerCase().includes(q)
      );
    });
  }, [childrenRes.data, search, groupFilter, statusFilter]);

  const save = useMutation({
    mutationFn: async () => {
      const parsed = childSchema.safeParse({
        full_name: form.full_name,
        parent_name: form.parent_name,
        parent_phone: form.parent_phone,
        group_id: form.group_id,
        monthly_fee: Number(form.monthly_fee || 0),
      });
      if (!parsed.success) throw new Error(parsed.error.issues[0]!.message);

      const payload = {
        full_name: parsed.data.full_name,
        birth_date: form.birth_date || null,
        parent_name: parsed.data.parent_name,
        parent_phone: parsed.data.parent_phone,
        group_id: parsed.data.group_id,
        monthly_fee: parsed.data.monthly_fee,
        enrollment_date: form.enrollment_date || todayISO(),
        status: form.status,
        note: form.note || null,
      };

      if (editing) {
        const { error } = await supabase
          .from("children")
          .update(payload)
          .eq("id", editing.id);
        if (error) throw new Error(error.message);
      } else {
        const { data, error } = await supabase
          .from("children")
          .insert(payload)
          .select("id")
          .single();
        if (error) throw new Error(error.message);
        await notify(
          "child",
          "Yangi bola qo'shildi",
          `${payload.full_name} ro'yxatga olindi`,
          data?.id,
        );
      }
    },
    onSuccess: () => {
      toast.success(editing ? "Ma'lumot yangilandi" : "Bola qo'shildi");
      setModalOpen(false);
      setEditing(null);
      qc.invalidateQueries({ queryKey: ["children"] });
      qc.invalidateQueries({ queryKey: ["notifications"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (child: Child) => {
      const { error } = await supabase.from("children").delete().eq("id", child.id);
      if (error) throw new Error(error.message);
    },
    onSuccess: () => {
      toast.success("Bola o'chirildi");
      setDeleting(null);
      qc.invalidateQueries({ queryKey: ["children"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setModalOpen(true);
  }

  // Guruh kartasidan "Bola qo'shish" bosilganda — shu guruh tanlangan holda oyna ochiladi
  useEffect(() => {
    if (!add || !canEdit || groupsRes.isLoading) return;
    const g = groups.find((x) => x.id === add);
    setEditing(null);
    setForm({
      ...emptyForm,
      group_id: add,
      monthly_fee: g ? String(g.monthly_fee) : "0",
    });
    setModalOpen(true);
    void navigate({ search: { add: undefined }, replace: true });
  }, [add, canEdit, groupsRes.isLoading]); // eslint-disable-line react-hooks/exhaustive-deps

  function openEdit(child: Child) {
    setEditing(child);
    setForm({
      full_name: child.full_name,
      birth_date: child.birth_date ?? "",
      parent_name: child.parent_name ?? "",
      parent_phone: child.parent_phone ?? "",
      group_id: child.group_id ?? "",
      monthly_fee: String(child.monthly_fee ?? 0),
      enrollment_date: child.enrollment_date,
      status: child.status,
      note: child.note ?? "",
    });
    setModalOpen(true);
  }

  return (
    <>
      <PageTitle
        eyebrow={`${rows.length} ta yozuv`}
        title="Bolalar"
        actions={canEdit ? <PrimaryButton onClick={openCreate}>Bola qo'shish</PrimaryButton> : null}
      />

      <div className="px-5 py-6 lg:px-6">
        <Panel>
          <PanelHeader
            title="Bolalar ro'yxati"
            subtitle={`${(childrenRes.data ?? []).length} ta yozuv · ${groups.length} guruh`}
            actions={
              <>
                <SearchInput
                  value={search}
                  onChange={setSearch}
                  placeholder="Ism yoki telefon bo'yicha…"
                />
                <FilterSelect
                  ariaLabel="Guruh"
                  value={groupFilter}
                  onChange={setGroupFilter}
                  options={[
                    { value: "all", label: "Guruh: Barchasi" },
                    ...groups.map((g) => ({ value: g.id, label: g.name })),
                  ]}
                />
                <FilterSelect
                  ariaLabel="Holat"
                  value={statusFilter}
                  onChange={setStatusFilter}
                  options={[
                    { value: "all", label: "Holat: Barchasi" },
                    { value: "active", label: "Faol" },
                    { value: "waiting", label: "Navbatda" },
                    { value: "left", label: "Chiqib ketgan" },
                  ]}
                />
              </>
            }
          />

          {childrenRes.isLoading ? (
            <LoadingRows />
          ) : childrenRes.error ? (
            <ErrorNote message={(childrenRes.error as Error).message} />
          ) : rows.length === 0 ? (
            <EmptyState
              title="Bola topilmadi"
              hint="Filtrlarni o'zgartiring yoki yangi bola qo'shing."
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-border/60 text-[11px] uppercase tracking-wider text-muted-foreground">
                    <th className="px-5 py-3 font-medium">Bola</th>
                    <th className="px-5 py-3 font-medium">Ota-ona</th>
                    <th className="hidden px-5 py-3 font-medium md:table-cell">Telefon</th>
                    <th className="px-5 py-3 font-medium">Guruh</th>
                    <th className="hidden px-5 py-3 font-medium sm:table-cell">Oylik to'lov</th>
                    <th className="px-5 py-3 font-medium">To'lov holati</th>
                    <th className="px-5 py-3 text-right font-medium">Amallar</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/40">
                  {rows.map((c) => {
                    const s = summarize(
                      c,
                      monthPayments.filter((p) => p.child_id === c.id),
                    );
                    const group = groups.find((g) => g.id === c.group_id);
                    return (
                      <tr key={c.id} className="hover:bg-primary/5">
                        <td className="px-5 py-3.5">
                          <div className="flex items-center gap-3">
                            <div className="grid size-9 place-items-center rounded-full bg-primary/12 text-xs font-semibold text-primary ring-1 ring-primary/25">
                              {initials(c.full_name)}
                            </div>
                            <div>
                              <p className="font-medium text-foreground">{c.full_name}</p>
                              <p className="text-[11px] text-muted-foreground">
                                {formatDate(c.birth_date)} · #{c.child_code} ·{" "}
                                {STATUS_LABELS[c.status]}
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="px-5 py-3.5 text-muted-foreground">
                          {c.parent_name || "—"}
                        </td>
                        <td className="hidden px-5 py-3.5 text-muted-foreground md:table-cell">
                          {c.parent_phone || "—"}
                        </td>
                        <td className="px-5 py-3.5">
                          {group ? (
                            <span className="rounded-lg bg-accent/12 px-2.5 py-1 text-[12px] text-accent ring-1 ring-accent/25">
                              {group.name}
                            </span>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </td>
                        <td className="hidden px-5 py-3.5 text-foreground sm:table-cell">
                          {formatUZS(c.monthly_fee)}
                        </td>
                        <td className="px-5 py-3.5">
                          {s.status === "paid" ? (
                            <Pill tone="primary">To'langan</Pill>
                          ) : s.status === "partial" ? (
                            <Pill tone="warning">Qisman · {formatUZS(s.debt)} qarz</Pill>
                          ) : (
                            <Pill tone="muted">To'lanmagan</Pill>
                          )}
                        </td>
                        <td className="px-5 py-3.5 text-right">
                          <div className="flex justify-end gap-1">
                            <Link
                              to="/children/$childId"
                              params={{ childId: c.id }}
                              search={{ add: undefined }}
                              className="rounded-lg px-2.5 py-1 text-[12px] text-muted-foreground ring-1 ring-border/60 hover:text-foreground"
                            >
                              Profil
                            </Link>
                            {canEdit ? (
                              <>
                                <GhostButton onClick={() => openEdit(c)}>Tahrirlash</GhostButton>
                                <GhostButton onClick={() => setDeleting(c)}>O'chirish</GhostButton>
                              </>
                            ) : null}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </Panel>
      </div>

      <FormModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        title={editing ? "Bolani tahrirlash" : "Yangi bola"}
        description="Bola va ota-ona ma'lumotlarini kiriting."
        submitting={save.isPending}
        onSubmit={() => save.mutate()}
      >
        {groups.length === 0 && !editing ? (
          <div className="rounded-xl bg-warning/10 px-4 py-3 text-sm text-foreground ring-1 ring-warning/30">
            Avval guruh oching — bola qaysi guruhga qo'yilishi tanlanishi shart.{" "}
            <Link to="/groups" className="font-semibold text-primary underline">
              Guruh ochish
            </Link>
          </div>
        ) : null}
        <TextField
          label="To'liq ism"
          required
          value={form.full_name}
          onChange={(v) => setForm({ ...form, full_name: v })}
        />
        <div className="grid gap-3 sm:grid-cols-2">
          <TextField
            label="Tug'ilgan sana"
            type="date"
            value={form.birth_date}
            onChange={(v) => setForm({ ...form, birth_date: v })}
          />
          <TextField
            label="Qabul sanasi"
            type="date"
            value={form.enrollment_date}
            onChange={(v) => setForm({ ...form, enrollment_date: v })}
          />
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <TextField
            label="Ota-ona ismi"
            value={form.parent_name}
            onChange={(v) => setForm({ ...form, parent_name: v })}
          />
          <TextField
            label="Telefon"
            value={form.parent_phone}
            placeholder="+998 90 123 45 67"
            onChange={(v) => setForm({ ...form, parent_phone: v })}
          />
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <SelectField
            label="Qaysi guruhga?"
            value={form.group_id}
            onChange={(v) => {
              const g = groups.find((x) => x.id === v);
              setForm({
                ...form,
                group_id: v,
                monthly_fee:
                  g && Number(form.monthly_fee) === 0 ? String(g.monthly_fee) : form.monthly_fee,
              });
            }}
            options={[
              { value: "", label: "— Guruh tanlang —" },
              ...groups.map((g) => ({ value: g.id, label: g.name })),
            ]}
          />
          <TextField
            label="Oylik to'lov (UZS)"
            type="number"
            value={form.monthly_fee}
            onChange={(v) => setForm({ ...form, monthly_fee: v })}
          />
        </div>
        <SelectField
          label="Holat"
          value={form.status}
          onChange={(v) => setForm({ ...form, status: v })}
          options={[
            { value: "active", label: "Faol" },
            { value: "waiting", label: "Navbatda" },
            { value: "left", label: "Chiqib ketgan" },
          ]}
        />
        <TextField
          label="Izoh"
          value={form.note}
          onChange={(v) => setForm({ ...form, note: v })}
        />
      </FormModal>

      <ConfirmDialog
        open={deleting !== null}
        onOpenChange={(v) => !v && setDeleting(null)}
        title="Bolani o'chirish"
        description={`${deleting?.full_name ?? ""} va unga bog'liq davomat hamda to'lovlar butunlay o'chiriladi. Davom etasizmi?`}
        onConfirm={() => deleting && remove.mutate(deleting)}
      />
    </>
  );
}
