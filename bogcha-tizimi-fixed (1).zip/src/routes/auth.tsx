import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";

export const Route = createFileRoute("/auth")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Kirish — Bog'cha boshqaruv tizimi" },
      {
        name: "description",
        content: "Bog'cha xodimlari uchun xavfsiz kirish va ro'yxatdan o'tish.",
      },
      { property: "og:title", content: "Kirish — Bog'cha boshqaruv tizimi" },
      { property: "og:description", content: "Xodimlar uchun xavfsiz kirish." },
    ],
  }),
  component: AuthPage,
});

const schema = z.object({
  email: z.string().trim().email({ message: "Email noto'g'ri" }).max(255),
  password: z.string().min(6, { message: "Parol kamida 6 belgi" }).max(72),
  fullName: z.string().trim().max(100).optional(),
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/dashboard", replace: true });
    });
  }, [navigate]);

  async function afterAuth() {
    await supabase.rpc("setup_current_user", { _full_name: fullName || "" });
    navigate({ to: "/dashboard", replace: true });
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = schema.safeParse({ email, password, fullName });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Ma'lumot noto'g'ri");
      return;
    }
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email: parsed.data.email,
          password: parsed.data.password,
          options: { emailRedirectTo: window.location.origin },
        });
        if (error) throw error;
        toast.success("Hisob yaratildi");
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email: parsed.data.email,
          password: parsed.data.password,
        });
        if (error) throw error;
      }
      await afterAuth();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Kirishda xatolik");
    } finally {
      setLoading(false);
    }
  }

  async function google() {
    setLoading(true);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      setLoading(false);
      toast.error("Google orqali kirishda xatolik");
      return;
    }
    if (result.redirected) return;
    await afterAuth();
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-5 py-10">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-40 -left-32 size-[520px] rounded-full bg-accent/10 blur-[120px]" />
        <div className="absolute bottom-[-200px] right-0 size-[560px] rounded-full bg-primary/10 blur-[140px]" />
      </div>

      <div className="relative w-full max-w-md rounded-2xl bg-card/70 p-7 ring-1 ring-border/60">
        <div className="grid size-10 place-items-center rounded-xl bg-primary/15 ring-1 ring-primary/30">
          <span className="glowdot block size-3.5 rounded-full bg-primary shadow-glow" />
        </div>
        <h1 className="mt-5 font-display text-2xl font-medium text-foreground">
          {mode === "login" ? "Tizimga kirish" : "Ro'yxatdan o'tish"}
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Bog'cha xodimlari uchun. Yangi xodimlar "Tarbiyachi" roli bilan ochiladi —
          administrator rolini mavjud admin belgilaydi.
        </p>

        <form onSubmit={submit} className="mt-6 space-y-3">
          {mode === "signup" ? (
            <Field
              label="To'liq ism"
              value={fullName}
              onChange={setFullName}
              placeholder="Aziza Karimova"
            />
          ) : null}
          <Field
            label="Email"
            type="email"
            value={email}
            onChange={setEmail}
            placeholder="xodim@bogcha.uz"
          />
          <Field
            label="Parol"
            type="password"
            value={password}
            onChange={setPassword}
            placeholder="••••••"
          />
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-glow disabled:opacity-60"
          >
            {loading ? "Yuklanmoqda…" : mode === "login" ? "Kirish" : "Ro'yxatdan o'tish"}
          </button>
        </form>

        <button
          onClick={google}
          disabled={loading}
          className="mt-3 w-full rounded-xl bg-surface px-4 py-2.5 text-sm font-medium text-foreground ring-1 ring-border/60 disabled:opacity-60"
        >
          Google orqali kirish
        </button>

        <button
          onClick={() => setMode(mode === "login" ? "signup" : "login")}
          className="mt-5 w-full text-center text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          {mode === "login"
            ? "Hisobingiz yo'qmi? Ro'yxatdan o'ting"
            : "Hisobingiz bormi? Kirish"}
        </button>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  placeholder?: string;
}) {
  return (
    <label className="block">
      <span className="text-[12px] text-muted-foreground">{label}</span>
      <input
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-xl bg-surface px-3 py-2.5 text-sm text-foreground outline-none ring-1 ring-border/60 placeholder:text-muted-foreground/70 focus:ring-primary/50"
      />
    </label>
  );
}
