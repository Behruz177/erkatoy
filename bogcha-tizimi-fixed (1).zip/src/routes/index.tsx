import { useEffect } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Bog'cha boshqaruv tizimi — bolalar, davomat va to'lovlar" },
      {
        name: "description",
        content:
          "Bolalar ro'yxati, davomat, oylik to'lovlar, qarzdorlik va navbat — barchasi bitta tizimda.",
      },
      { property: "og:title", content: "Bog'cha boshqaruv tizimi" },
      {
        property: "og:description",
        content: "Bolalar, davomat, to'lovlar va qarzdorlikni oson boshqaring.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  const navigate = useNavigate();

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/dashboard", replace: true });
    });
  }, [navigate]);

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-5">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-40 -left-32 size-[520px] rounded-full bg-accent/10 blur-[120px]" />
        <div className="absolute bottom-[-200px] right-0 size-[560px] rounded-full bg-primary/10 blur-[140px]" />
      </div>
      <div className="relative w-full max-w-md rounded-2xl bg-card/70 p-8 ring-1 ring-border/60">
        <div className="grid size-10 place-items-center rounded-xl bg-primary/15 ring-1 ring-primary/30">
          <span className="glowdot block size-3.5 rounded-full bg-primary shadow-glow" />
        </div>
        <h1 className="mt-5 font-display text-3xl font-medium text-foreground">
          Bog'cha boshqaruv tizimi
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Bolalar, davomat, oylik to'lovlar, qarzdorlik va navbat ro'yxati — bitta
          joyda, xavfsiz saqlanadi.
        </p>
        <Link
          to="/auth"
          className="mt-6 inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-glow"
        >
          <span className="size-1.5 rounded-full bg-primary-foreground" />
          Tizimga kirish
        </Link>
      </div>
    </div>
  );
}
