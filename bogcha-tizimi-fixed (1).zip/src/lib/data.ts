import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type Group = Database["public"]["Tables"]["groups"]["Row"];
export type Child = Database["public"]["Tables"]["children"]["Row"];
export type Attendance = Database["public"]["Tables"]["attendance"]["Row"];
export type Payment = Database["public"]["Tables"]["payments"]["Row"];
export type WaitingItem = Database["public"]["Tables"]["waiting_list"]["Row"];
export type NotificationRow = Database["public"]["Tables"]["notifications"]["Row"];
export type AppRole = Database["public"]["Enums"]["app_role"];

function unwrap<T>(res: { data: T | null; error: { message: string } | null }): T {
  if (res.error) throw new Error(res.error.message);
  return (res.data ?? []) as T;
}

export const groupsQuery = () =>
  queryOptions({
    queryKey: ["groups"],
    queryFn: async () =>
      unwrap<Group[]>(await supabase.from("groups").select("*").order("name")),
  });

export const childrenQuery = () =>
  queryOptions({
    queryKey: ["children"],
    queryFn: async () =>
      unwrap<Child[]>(
        await supabase.from("children").select("*").order("full_name"),
      ),
  });

export const childQuery = (id: string) =>
  queryOptions({
    queryKey: ["children", id],
    queryFn: async () => {
      const res = await supabase.from("children").select("*").eq("id", id).maybeSingle();
      if (res.error) throw new Error(res.error.message);
      return res.data as Child | null;
    },
  });

export const attendanceByDateQuery = (date: string) =>
  queryOptions({
    queryKey: ["attendance", "date", date],
    queryFn: async () =>
      unwrap<Attendance[]>(
        await supabase.from("attendance").select("*").eq("date", date),
      ),
  });

export const attendanceRangeQuery = (from: string, to: string) =>
  queryOptions({
    queryKey: ["attendance", "range", from, to],
    queryFn: async () =>
      unwrap<Attendance[]>(
        await supabase
          .from("attendance")
          .select("*")
          .gte("date", from)
          .lte("date", to)
          .order("date"),
      ),
  });

export const attendanceByChildQuery = (childId: string) =>
  queryOptions({
    queryKey: ["attendance", "child", childId],
    queryFn: async () =>
      unwrap<Attendance[]>(
        await supabase
          .from("attendance")
          .select("*")
          .eq("child_id", childId)
          .order("date", { ascending: false }),
      ),
  });

export const paymentsQuery = () =>
  queryOptions({
    queryKey: ["payments"],
    queryFn: async () =>
      unwrap<Payment[]>(
        await supabase.from("payments").select("*").order("paid_at", { ascending: false }),
      ),
  });

export const waitingListQuery = () =>
  queryOptions({
    queryKey: ["waiting_list"],
    queryFn: async () =>
      unwrap<WaitingItem[]>(
        await supabase.from("waiting_list").select("*").order("position"),
      ),
  });

export const notificationsQuery = () =>
  queryOptions({
    queryKey: ["notifications"],
    queryFn: async () =>
      unwrap<NotificationRow[]>(
        await supabase
          .from("notifications")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(30),
      ),
  });

export async function notify(
  type: string,
  title: string,
  message: string,
  childId?: string | null,
) {
  await supabase
    .from("notifications")
    .insert({ type, title, message, child_id: childId ?? null });
}

/** Payment summary for one child in one period */
export interface PaymentSummary {
  required: number;
  paid: number;
  debt: number;
  status: "paid" | "partial" | "unpaid";
  lastPaidAt: string | null;
}

export function summarize(
  child: Pick<Child, "monthly_fee">,
  payments: Payment[],
): PaymentSummary {
  const required = Number(child.monthly_fee ?? 0);
  const paid = payments.reduce((s, p) => s + Number(p.amount), 0);
  const debt = Math.max(required - paid, 0);
  const lastPaidAt =
    payments.length > 0
      ? payments.map((p) => p.paid_at).sort().reverse()[0] ?? null
      : null;
  const status: PaymentSummary["status"] =
    paid <= 0 ? "unpaid" : debt > 0 ? "partial" : "paid";
  return { required, paid, debt, status, lastPaidAt };
}

/** Oylik to'lovning nechanchi hissasi to'langan */
export interface ShareInfo {
  percent: number;
  ratio: number;
  label: string;
}

export function shareInfo(required: number, paid: number): ShareInfo {
  const ratio = required > 0 ? paid / required : paid > 0 ? 1 : 0;
  const percent = Math.round(Math.min(ratio, 1) * 100);
  const label =
    required <= 0
      ? "To'lov belgilanmagan"
      : percent >= 100
        ? "To'liq to'langan"
        : `${percent}% — ${percent === 0 ? "to'lov yo'q" : "qisman"}`;
  return { percent, ratio, label };
}
